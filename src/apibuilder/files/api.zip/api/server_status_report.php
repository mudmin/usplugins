<?php
function getLatestFile($dir) {
    $latest_ctime = 0;
    $latest_filename = '';    
    $d = dir($dir);
    while (false !== ($entry = $d->read())) {
        $filepath = "{$dir}/{$entry}";
        if (is_file($filepath) && filectime($filepath) > $latest_ctime) {
            $latest_ctime = filectime($filepath);
            $latest_filename = $filepath;
        }
    }
    $d->close();
    return $latest_filename;
}

function formatFileInfo($file) {
    if (file_exists($file)) {
        $size = round(filesize($file) / 1024 / 1024, 2) . " MB";
        $date = date("Y-m-d H:i:s", filemtime($file));
        return "$date - $size";
    }
    return "No file found";
}

function getSpaceLeft($path) {
    $free_space = disk_free_space($path);
    return round($free_space / 1024 / 1024 / 1024, 2) . " GB";
}

$prev_report_file = "/tmp/previous_report.txt";
$current_report = [];

// 1. Space left on server
$space_left = getSpaceLeft("/");
$current_report[] = ["Space left on server", $space_left];

// 2-7. Backup file information
$backups = [
    "/home/bak/dev/db" => "Dev database",
    "/home/bak/portal/db" => "Portal database",
    "/home/bak/cms/db" => "CMS database",
    "/home/bak/cms/cmsdata" => "CMS data",
    "/home/bak/dev/customerdata" => "Dev customer data",
    "/home/bak/portal/customerdata" => "Portal customer data"
];

foreach ($backups as $path => $name) {
    $latest_file = getLatestFile($path);
    $file_info = formatFileInfo($latest_file);
    $current_report[] = ["Latest ". $name . " backup", $file_info];
}

// Generate HTML report
$html_report = "
<html>
<head>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .changed {
            background-color: #fffacd;
        }
    </style>
</head>
<body>
    <h2>Server Status Report - " . date('Y-m-d') . "</h2>
    <table>
        <tr>
            <th>Item</th>
            <th>Current</th>
            <th>Previous</th>
        </tr>";

// Compare with previous report if it exists
$prev_report = [];
if (file_exists($prev_report_file)) {
    $prev_report = unserialize(file_get_contents($prev_report_file));
}

foreach ($current_report as $index => $row) {
    $item = $row[0];
    $current_value = $row[1];
    $previous_value = isset($prev_report[$index]) ? $prev_report[$index][1] : "N/A";
    $changed = ($current_value !== $previous_value) ? ' class="changed"' : '';
    $html_report .= "<tr$changed>
                        <td>{$item}</td>
                        <td>{$current_value}</td>
                        <td>{$previous_value}</td>
                     </tr>";
}

$html_report .= "
    </table>
</body>
</html>";

// Save current report as previous for next run
file_put_contents($prev_report_file, serialize($current_report));

// Email settings
$to = 'mudmin@gmail.com';
$subject = 'Server Status Report - ' . date('Y-m-d');

email($to, $subject, $html_report);

echo "Report sent successfully.";
?>