<?php
require_once '../users/init.php';
$ip = ipCheck();

// Log IP and headers
$headers = getallheaders();
logger(1, "doc_response", "IP: $ip, Headers: " . json_encode($headers));

$get = Input::sanitize($_GET);
logger(1, 'ai_response_parser', 'GET: ' . json_encode($get));
// Handle webhook response if parameters are present
if (isset($_GET['method']) && $_GET['method'] == 'summarize_progress') {
    handleWebhookResponse($_GET);
    exit();
}

function handleWebhookResponse($params)
{
    global $db;
    $ai_servers = [];
    $servers = $db->query("SELECT * FROM omt_servers_internal WHERE summarize = 1")->results();
    foreach($servers as $server){
        $ai_servers[$server->id] = $server->url;
    }

    // Validate required parameters
    $required = ['id_value', 'status', 'response_msg', 'success', 'server_id'];
    foreach ($required as $req) {
        if (!isset($params[$req])) {
            logger(1, "ai_summary", "Missing required parameter: " . $req);
            http_response_code(400);
            exit("Missing required parameter: " . $req);
        }
    }

    // If successful, fetch the output file
    if ($params['status'] == 'complete' && $params['success'] == 1) {
        logger(1, "ai_summary", "Attempting to mark Job complete: " . $params['id_value']);
        $server_url = $ai_servers[$params['server_id']] ?? null;
        if (!$server_url) {
            logger(1, "ai_summary", "Invalid server_id: " . $params['server_id']);
            http_response_code(400);
            exit("Invalid server_id");
        }

        // Build the output file URL
        $output_url = $server_url . "summarize/docs/output/" . $params['id_value'] . ".txt";
        logger(1, "ai_summary", "Fetching summary file: " . $output_url);
        
        // Fetch the output file
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $output_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);

        if (ipCheck() == "::1") {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }

        $summary_text = curl_exec($ch);

        if (curl_errno($ch)) {
            logger(1, "ai_summary", "Failed to fetch summary file: " . curl_error($ch));
            $fields = [
                'completed' => 1,
                'completed_on' => date('Y-m-d H:i:s'),
                'failed' => 1,
                'failed_msg' => "Failed to fetch summary file: " . Input::sanitize(curl_error($ch))
            ];
        } else {
            // Update the job with the summary
            $fields = [
                'completed' => 1,
                'completed_on' => date('Y-m-d H:i:s'),
                'failed' => 0,
                'last_status_on' => date('Y-m-d H:i:s')
            ];
        }
        curl_close($ch);

        // Fetch the job details
        $fetchJobQ = $db->query("SELECT * FROM omt_ai_jobs WHERE id = ?", [$params['id_value']]);
        $fetchJobC = $fetchJobQ->count();
        if ($fetchJobC < 1) {
            logger(1, "ai_summary", "Job not found: " . $params['id_value']);
            http_response_code(400);
            exit("Job not found");
        }
        $fetchJob = $fetchJobQ->first();

        // Update the job record
        $result = $db->update('omt_ai_jobs', $params['id_value'], $fields);
        $error = $db->errorString();
        logger(1, "ai_summary_update", "Database update " . $error);

        // Update summary status in the original table
        $table = $fetchJob->table_name;
        $row_id = $fetchJob->row_id;

        // Validate table name to prevent SQL injection
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) {
            logger(1, "ai_summary", "Invalid table name: " . $table);
            http_response_code(400);
            exit("Invalid table name");
        }

        $db->update($table, $row_id, [
            'summary_status' => 2,
            'summary_status_ts' => date('Y-m-d H:i:s'),
        ]);
        logger(1, "ai_summary_update", "Summary status updated - $table $row_id " . $db->errorString());

        // Define summary table mappings
        $summaryTables = [
            'omt_meetings' => ['target' => 'omt_meeting_ai_summaries', 'field' => '_mid'],
            'omt_meeting_minute_data' => ['target' => 'omt_meeting_minute_item_ai_summaries', 'field' => 'item_id'],
            'omt_meeting_minute_instance' => ['target' => 'omt_meeting_minute_ai_summaries', 'field' => 'instance'],
        ];

        // Store the summary in the appropriate table (single insertion)
        if (isset($summaryTables[$table])) {
            $summaryTable = $summaryTables[$table];
            $targetTable = $summaryTable['target'];
            //remote leading underscores from field name
            $key = ltrim($summaryTable['field'], "_");

            
            // Check for existing versions
            $ver = 1;
            $checkQ = $db->query("SELECT ver FROM $targetTable WHERE $key = ?", [$fetchJob->asset_id]);
            if ($checkQ->count() > 0) {
                $ver = $checkQ->first()->ver + 1;
            }

            // Prepare and insert summary record
            $fields = [
                'ver' => $ver,
                'cid' => $fetchJob->cid,
                'gid' => $fetchJob->gid,
                $key => $fetchJob->asset_id,
                'job_type' => $fetchJob->job_type,
                'summary' => Input::sanitize($summary_text),
                'job_id' => $params['id_value'],
                'ts' => date('Y-m-d H:i:s')
            ];
            if($fetchJob->instance > 0){
                $fields['instance'] = $fetchJob->instance;
            }

            $db->insert($targetTable, $fields);
            logger(1, "ai_summary_update", "Summary stored in $targetTable " . $db->errorString());
        }

    } else {
        // Update job as failed
        $fields = [
            'completed' => 1,
            'completed_on' => date('Y-m-d H:i:s'),
            'failed' => 1,
            'failed_msg' => Input::sanitize($params['response_msg'])
        ];
        $db->update('omt_ai_jobs', $params['id_value'], $fields);
        logger(1, "ai_summary", "Job failed: " . $params['response_msg']);
        logger(1, "ai_summary", "Job failed: " . json_encode($params));
        logger(1, "ai_summary", "Job failed: " . $db->errorString());
    }

    http_response_code(200);
    exit("OK");
}