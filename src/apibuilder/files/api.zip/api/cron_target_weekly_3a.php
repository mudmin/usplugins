<?php
require_once "../users/init.php";
require_once $abs_us_root.$us_url_root."admin/functions/takeout.php";

$code = Input::get('code');

if($code != "VocKbKd7B0b7e"){
  die("np");
}


$ip = ipCheck();
require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if(!hasPerm(2) && !in_array($ip, $valid_sync_ips)){
  die("np");
}

if($server_tag == "portal"){
  include $abs_us_root . $us_url_root . 'api/includes/soc2.php';
  $db->query("UPDATE plg_zoho_accounts SET `page` = ?",[0]);
  fetchZohoCRM(false,"Accounts");
  }

