<?php
require_once "../users/init.php";
$code = Input::get('code');



if($code != "VocKbKd7B0b7e"){
  die("np");
}

$ip = ipCheck();

require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if(!hasPerm(2) && !in_array($ip, $valid_sync_ips)){
  die("np");
}

//find customers that do not have support users and create them
$cust = $db->query("SELECT omt_customers.*
FROM omt_customers
LEFT JOIN users ON omt_customers.id = users.cid AND users.support_user = 1
WHERE users.id IS NULL")->results();
foreach($cust as $c){
  $attempt = generateCustomerSupportUser($c->id);
  lidump($attempt);
}
$badConfigs = $db->query("SELECT id FROM omt_configs WHERE gid = 0")->results();
foreach($badConfigs as $bc){
  lidump("Dealing with config ".$bc->id);
  deleteConfig($bc->id);
}

$noSlug = $db->query("SELECT id, custName FROM omt_customers WHERE slug = ''")->results();
foreach($noSlug as $n){

$proposed_slug = create_url_slug($n->custName);
$unique_slug = check_and_append_unique($proposed_slug, $n->id, 'is_slug_unique', 'customer', null);
$db->update("omt_customers",$n->id,['slug'=>$unique_slug]);
}

$noSlug = $db->query("SELECT id, groupName, customerId FROM omt_groups WHERE slug = ''")->results();
foreach($noSlug as $n){

$proposed_slug = create_url_slug($n->groupName);

$unique_slug = check_and_append_unique($proposed_slug, $n->customerId, 'is_slug_unique','group', $n->id);
$db->update("omt_groups",$n->id,['slug'=>$unique_slug]);

}

//we're going to do some sanity checks on locks to catch some tomfoolery
$locks = $db->query("SELECT * FROM omt_api_sessions WHERE active = 1 AND group_id > ? LIMIT 5",[0])->results();
$illegal = "";
foreach($locks as $l){

  //does the user id match the group id
  $check = $db->query("SELECT id FROM omt_user_group_map WHERE userId = ? AND groupId = ?",[$l->user_id,$l->group_id])->count();
  if($check < 1){
    $illegal .= "User ID: ".$l->user_id." locked Group ID: ".$l->group_id." Session ID: ".$l->id." but they do not belong to that group.\n";
  }
  if($check > 0){
    if($l->meeting_lock > 0){
      $check = $db->query("SELECT id FROM omt_meetings WHERE id = ? AND _gid = ?",[$l->meeting_lock,$l->group_id])->count();
      if($check < 1){
        $illegal .= "User ID: ".$l->user_id." locked Meeting ID: ".$l->meeting_lock." Session ID: ".$l->id." but that meeting does not belong to that group or does not exist.\n";
      }
    }

    if($l->config_lock > 0){
      $check = $db->query("SELECT id FROM omt_configs WHERE id = ? AND gid = ?",[$l->config_lock,$l->group_id])->count();
      if($check < 1){
        $illegal .= "User ID: ".$l->user_id." locked Config ID: ".$l->config_lock." Session ID: ".$l->id." but that config does not belong to that group or does not exist.\n";
      }
    }
  }
}

$users = $db->query("SELECT id FROM users WHERE apibld_key IS NULL OR apibld_key = ''")->results();
foreach($users as $u){
  $code = strtoupper(randomstring(12) . uniqid());
  $code = substr(chunk_split($code, 5, '-'), 0, -1);
  $db->update('users',$u->id,['apibld_key'=>$code]);
}

$null = $db->query("SELECT id from omt_agenda_configs WHERE numbering IS NULL")->results();
foreach($null as $n){
  $db->update('omt_agenda_configs',$n->id,['numbering' => '{"styles":["decimal","decimal"],"separator":".","show_parent":true,"show_trailing_zero":false,"trailing_char":"."}']);
}


if($illegal != ""){
  email("mudmin@gmail.com","Lock Security $actual_site_url", $illegal);
}

if($server_tag == "portal"){
  if(isset($user) && $user->isLoggedIn() && hasPerm(2)){
    $attempt =fetchZohoCRM(false,"Accounts");
    lidump($attempt);
  }else{
    fetchZohoCRM(false,"Accounts");
  }
  }

