<?php
require_once "../users/init.php";
//this file is called in the daily cron but can also be called directly  

$file_based_logging = false;

if($file_based_logging){
    $log_file = $abs_us_root . $us_url_root . "api/" . date("Y-m-d_H-i-s") . "_language.log.php";
    $log_content = "<?php die; ?>\n\n";
    file_put_contents($log_file, $log_content);
}

function log_to_file($message) {
    global $file_based_logging, $abs_us_root, $us_url_root;
    if($file_based_logging) {
        $log_file = $abs_us_root . $us_url_root . "api/" . date("Y-m-d_H-i-s") . "_language.log.php";
        $timestamp = date("Y-m-d H:i:s");
        $log_message = "[{$timestamp}] {$message}\n";
        file_put_contents($log_file, $log_message, FILE_APPEND);
    }
}

$code = Input::get('code');
logger(1,"Fetch language hit", "code: $code");
log_to_file("Fetch language hit with code: $code");

if($code != "VocKbKd7B0b7e"){
  log_to_file("Invalid code provided. Access denied.");
  die("np");
}
$ip = ipCheck();
log_to_file("IP Check: " . $ip);

$targetUrl = 'https://cms.omt-appserver.com/api/fetch_language.php';
$fields = ['fetch'=>true];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $targetUrl);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
log_to_file("Initiating curl request to {$targetUrl}");
$response = curl_exec($ch);

// Log the raw response
log_to_file("Raw API Response:");
log_to_file("Response length: " . strlen($response));
log_to_file("First 1000 characters of response:");
log_to_file(substr($response, 0, 1000));
log_to_file("Last 1000 characters of response:");
log_to_file(substr($response, -1000));

if (curl_errno($ch)) {
    $error = curl_error($ch);
    log_to_file("Curl error: " . $error);
    echo 'Curl error: ' . $error;
}
log_to_file("Curl request completed");

curl_close($ch);
require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';

$data = json_decode($response);


// Log json_decode errors if any
if(json_last_error() !== JSON_ERROR_NONE) {
    log_to_file("JSON Decode Error: " . json_last_error_msg());
}

// Log the decoded data structure
log_to_file("Decoded data structure:");
log_to_file("Type of data: " . gettype($data));
if(is_object($data)) {
    log_to_file("Available tables: " . implode(", ", array_keys((array)$data)));
}

foreach($data as $table=>$v){
  log_to_file("Processing table: {$table}");
  if($table == "cms_migrations"){
    $path = $abs_us_root . $us_url_root . 'admin/patch_shared.php';
    log_to_file("Writing to patch_shared.php");
    $myfile = fopen($path, "w");
    $txt = base64_decode($v);
    fwrite($myfile, $txt);
    fclose($myfile);
    include $path;
    log_to_file("Completed processing cms_migrations");
    continue;
  }
  
  if(!in_array($table, $tables)){
    $msg = "Received invalid table in language call";
    $msg .= "<br>Table: $table";
    $msg .= "IP: ".ipCheck();
    $msg .= "Server: ". whatServerIsThis();
    log_to_file("ERROR: " . $msg);
    log_to_file("Valid tables are: " . implode(", ", $tables));
    email("mudmin@gmail.com", "Received invalid table ()in language call on $actual_site_url",$msg );
    continue;
  }else{
    log_to_file("Processing valid table: {$table}");
    log_to_file("Table data count: " . count((array)$v));
    log_to_file("Truncating table {$table}");
    $db->query("TRUNCATE TABLE $table");
    $error = $db->errorString();
    if($error) {
      log_to_file("Database error during truncate of {$table}: " . $error);
    }
    
    $rowCount = 0;
    foreach($v as $row){
      $db->insert($table, (array)$row);
      $error = $db->errorString();
      if($error) {
        log_to_file("Database error inserting into {$table}: " . $error);
      }
      $rowCount++;
      if($rowCount == 1) {
        log_to_file("Sample first row for {$table}: " . json_encode($row));
      }
    }
    log_to_file("Inserted {$rowCount} rows into {$table}");
  }
}

log_to_file("Writing userspice english language file");
echo "Writing userspice english language file";
$path = $abs_us_root  . $us_url_root . 'usersc/lang/en-US.php';

$myfile = fopen($path, "w") or die("Unable to open file!");
$txt = "<?php\n";
$txt .= "\n\$lang = array_merge(\$lang, array(\n";
$keys = $db->query("SELECT * FROM omt_lang_strings WHERE section = 11")->results();
foreach($keys as $k=>$v){
  $transQ = $db->query("SELECT * FROM omt_lang_strings_trans WHERE lang = 1 AND string_id = ?",[$v->id]);
  $transC = $transQ->count();
  if($transC < 1){
    log_to_file("No translation found for shortcode: {$v->shortcode}");
  }else{
    $trans = $transQ->first();
    $sc = strtoupper($v->shortcode);
    $sc = str_replace("-","_",$sc);
    $text = str_replace("'","\'",$trans->string);
    $txt .= "  '$sc' => '$text',\n";
  }
}
$txt .= "));\n";
$txt .= "?>";
fwrite($myfile, $txt);
fclose($myfile);
log_to_file("Completed writing english language file");

echo "<br>";
$checkQ = $db->query("SELECT * FROM omt_lang_strings WHERE shortcode IN ('qsc','ttp','reset-proav-message')");
$checkC = $checkQ->count();

if($checkC < 1){
  $msg = "WARNING - qsc not found in omt_lang_strings";
  log_to_file($msg);
  echo $msg . "<br>";
}else{
  echo "Writing default file...<br>";
  log_to_file("Writing default javascript file");
  $check = $checkQ->results();
  $default = $abs_us_root  . $us_url_root . 'customers/includes/default_js.php';
  $myfile = fopen($default, "w") or die("Unable to open file!");
  $txt = "<script>\n";
  foreach($check as $c){
    $fetch = $db->query("SELECT * FROM omt_lang_strings_trans WHERE lang = 1 AND string_id = ?",[$c->id])->first();
    if($c->shortcode == "qsc"){
        $txt .= "var qsc = `".$fetch->string."`;\n\n";
    }elseif($c->shortcode == "ttp"){
        $txt .= "var ttp = `".$fetch->string."`;\n\n";
    }elseif($c->shortcode == "reset-proav-message"){
        $txt .= "var confirmDefaultMessage = `".$fetch->string."`;\n\n";
    }
  }

  $txt .= "</script>";
  fwrite($myfile, $txt);
  fclose($myfile);
  log_to_file("Completed writing default javascript file");
  echo "Done writing file.<br>";
}
fetchOMTServers();


log_to_file("Script completed successfully");
echo "Success";