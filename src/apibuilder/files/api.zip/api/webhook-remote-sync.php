<?php
require_once("../users/init.php");
$ip = ipCheck();
echo "success";


require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';


if(!in_array($ip, $valid_sync_ips)){
    if(!hasPerm(2)){
        logger(1,"ILLEGAL - Webhook3 hit from", $ip);
        die("np - hp2");
    }
}
$job = Input::get('job');

// Read version and commit from deployed files
$ver = '';
$commit = '';

if(file_exists($abs_us_root . $us_url_root . '_version_control/ver.txt')){
  $ver = trim(file_get_contents($abs_us_root . $us_url_root . '_version_control/ver.txt'));
}

if(file_exists($abs_us_root . $us_url_root . '_version_control/commit.txt')){
  $commit = trim(file_get_contents($abs_us_root . $us_url_root . '_version_control/commit.txt'));
}

if(is_numeric($job)){
  $respond_to = "https://cms.omt-appserver.com/api/remote_deploy_response?job=".$job."&server=".$server_id;

  // Add ver and commit if found
  if(!empty($ver)){
    $respond_to .= "&ver=".$ver;
  }
  if(!empty($commit)){
    $respond_to .= "&commit=".urlencode($commit);
  }

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $respond_to);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  $output = curl_exec($ch);

  if(curl_errno($ch)) {
      $error = curl_error($ch);
      logger(1,"Curl error: ",$error);
      // Log or handle the error appropriately
      die("Curl error: " . $error);
  }else{
    logger(1,"Curl success: ",$output);
  }

  $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  if($http_code !== 200) {
      logger(1,"HTTP error: ",$http_code);
      // Log or handle non-200 response codes
      die("HTTP error: " . $http_code);
  }

  curl_close($ch);

}
