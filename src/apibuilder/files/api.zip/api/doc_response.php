<?php
require_once '../users/init.php';
$ip = ipCheck();

//we're going to use asset id 0 for general things
if(!isset($_POST['asset_id'])){
    $_POST['asset_id'] = 0;
}

logger("2", "doc_response_entry", "Request received from IP: $ip");

// Log IP and headers
$headers = getallheaders();
logger(1, "doc_response", "IP: $ip, Headers: " . json_encode($headers));
logger(2, "doc_response_headers", "Headers: " . json_encode($headers));

// Log request body
logger(1, "doc_response", "Request body: " . json_encode($_POST));
logger(2, "doc_response_body", "POST data: " . json_encode($_POST));

require_once $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if (!hasPerm(2) && !in_array($ip, $valid_sync_ips)) {
    logger(2, "doc_response_auth", "Auth failed for IP: $ip");
    email("mudmin@gmail.com", "doc response $actual_site_url", "FAILED. Invalid IP - " . $ip);
    die("np");
}

logger(2, "doc_response_auth", "IP validation passed for $ip");
logger(1, "doc_response", "hit");

$req = [
    'asset_id',
    'user_id',
    'cid',
    'gid',
    'api_job_id',
    'remote_document_server',
    'remote_document_path',
];



// Check for required fields
foreach ($req as $r) {
    if (!isset($_POST[$r])) {
        logger(2, "doc_response_fields", "Missing field: $r");
        echo "Missing required field: " . $r;
        logger(1, "doc_response", "Missing required field $r");
        logger(1, "doc_response", "Request body: " . json_encode($_POST));
        die();
    } elseif ($_POST[$r] === '') {
        logger(2, "doc_response_fields", "Empty field: $r");
        echo "Missing required field: " . $r;
        logger(1, "doc_response", "Empty required field $r");
        die();
    } else {
        $$r = $_POST[$r];
    }
}

logger(2, "doc_response_fields", "All required fields present. asset_id: $asset_id, api_job_id: $api_job_id");

$remote_document_server = base64_decode($remote_document_server);
$remote_document_path = base64_decode($remote_document_path);

logger(2, "doc_response_server", "Checking server $remote_document_server");
$checkQ = $db->query("SELECT * FROM omt_servers_internal WHERE `url` = ?", [$remote_document_server]);
$errorString = $db->errorString();
logger('1', 'doc_response', 'Checking server: ' . $remote_document_server. "es: $errorString");
$checkC = $checkQ->count(); 
if ($checkC == 0) {
    logger(2, "doc_response_server", "Invalid server: $remote_document_server");
    echo "Invalid document server";
    logger(1, "doc_response", "Invalid document server");
    die();
}
$check = $checkQ->first();
$api_server_id = $check->id;
logger(2, "doc_response_server", "Server validated: ID=$api_server_id" . json_encode($check));

if(empty($api_server_id)) {
    logger(2, "doc_response_server", "Server found but ID is empty for: $remote_document_server");
    echo "Invalid server configuration";
    logger(1, "doc_response", "Server found but ID is empty");
    die();
}



// Lookup job
$jobQ = $db->query("SELECT 
j.*,
jt.job_type as job_type_name
FROM omt_doc_jobs j 
LEFT OUTER JOIN omt_doc_job_types jt ON j.job_type = jt.id
WHERE j.api_job_id = ? 
AND j.asset_id = ? 
AND j.gid = ? 
AND j.cid = ?
AND j.api_server_id = ?
", [
    $api_job_id,
    $asset_id,
    $gid,
    $cid,
    $api_server_id
]);

$jobC = $jobQ->count();
if ($jobC == 0) {
    $es = $db->errorString();
    logger(2, "doc_response_job", "Job not found: api_job_id=$api_job_id, asset_id=$asset_id, Error: $es");
    logger(1, "doc_response", "$api_server_id Job not found for asset_id: $asset_id, api_job_id: $api_job_id, gid: $gid, cid: $cid ES $es");
    echo "Job not found";
    die();
}
$job = $jobQ->first();
logger(2, "doc_response_job", "Job found: " . json_encode($job));

$remote_document_path = "docs/output/".$job->api_job_id.".pdf";
logger(2, "doc_response_path", "Updated document path: $remote_document_path");

// Update job
$db->update('omt_doc_jobs', $job->id, [
    'server_responded' => 1,
    'server_responded_on' => date('Y-m-d H:i:s'),
    'remote_document_server' => $remote_document_server,
    'remote_document_path' => $remote_document_path
]);
logger(2, "doc_response_update", "Job updated with server response");
logger(1, "doc_response", "Job updated. Attempting to fetch file. $remote_document_server $remote_document_path");

// Fetch file
$basePath = $abs_us_root . $us_url_root . 'customerdata/tmp/pdf/';
if (!is_dir($basePath)) {
    mkdir($basePath, 0755, true);
}
$tempFilePath = $basePath . uniqid() . '.pdf';
$basePath = $abs_us_root . $us_url_root . 'customerdata/assets/' . $job->cid . '/' . $job->gid . '/';
if (!is_dir($basePath)) {
    mkdir($basePath, 0755, true);
}

if($asset_id > 0){
    $fn = $job->job_type_name . "_" . $asset_id . "_v" . $job->doc_ver_no . '.pdf';
}else{
    $fn = $job->job_type_name . "_" . $job->id . "_" . $job->api_job_id . '.pdf';
}

$finalFilePath = $basePath . $fn;

logger(2, "doc_response_paths", "Temp: $tempFilePath, Final: $finalFilePath");
//give the file a second or 2 to catch up.
sleep(5);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $remote_document_server . $remote_document_path);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36');

logger(2, "doc_response_fetch", "Attempting to fetch file from " . $remote_document_server . $remote_document_path);

// Open file handler for temporary file
$fileHandler = fopen($tempFilePath, 'wb');
if ($fileHandler === false) {
    logger(2, "doc_response_error", "Failed to open temp file: $tempFilePath");
    echo "Failed to open temporary file";
    logger(1, "doc_response", "Failed to open temporary file");
    die();
}
curl_setopt($ch, CURLOPT_FILE, $fileHandler);

// Execute cURL
$resp = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
logger(2, "doc_response_curl", "HTTP Code: $httpCode, Curl Error: $curlError");
logger("1","httpcode",$httpCode);
curl_close($ch);
fclose($fileHandler);
$later = [
    'fetch_later'=>1,
    'fetch_link'=>$remote_document_server . $remote_document_path,
];
if ($httpCode == 404) {
    logger(2, "doc_response_error", "404 Not Found: " . $remote_document_server . $remote_document_path);
    echo "File not found";
    logger(1, "doc_response", "File not found on remote server - ".$remote_document_server . $remote_document_path);
    $db->update('omt_doc_jobs', $job->id, $later);   
    unlink($tempFilePath); // Delete the temporary file if it was created
    die();
} elseif ($httpCode >= 400) {
    logger(2, "doc_response_error", "HTTP $httpCode error for " . $remote_document_server . $remote_document_path);
    echo "HTTP error: " . $httpCode;
    logger(1, "doc_response", "HTTP error: " . $httpCode);
    $db->update('omt_doc_jobs', $job->id, $later);   
    unlink($tempFilePath); // Delete the temporary file if it was created
    die();
} elseif (curl_errno($ch)) {
    logger(2, "doc_response_error", "Curl error: $curlError");
    echo "cURL error: " . curl_error($ch);
    logger(1, "doc_response", "cURL error: " . curl_error($ch));
    unlink($tempFilePath); // Delete the temporary file if it was created
    $db->update('omt_doc_jobs', $job->id, $later);   
    die();
}

// Move temporary file to final location
if (!rename($tempFilePath, $finalFilePath)) {
    logger(2, "doc_response_error", "Failed to move file from $tempFilePath to $finalFilePath");
    echo "Failed to move file to final location";
    logger(1, "doc_response", "Failed to move file to final location");
    die();
} else {
    logger(2, "doc_response_move", "File successfully moved to $finalFilePath");
    $ver = $job->doc_ver_no;
    if ($job->job_type == 1 || $job->job_type == 3) {
        $col = "mid";
        $tag = '6';
    } elseif ($job->job_type == 2 || $job->job_type == 4) {
        $tag = '7';
        $col = "instance";
    }elseif ($job->job_type == 5) {
        $tag = '8';
  
    }

    logger(2, "doc_response_tag", "Processing with type=$job->job_type, col=$col, tag=$tag");
    $attempt = logAndTagFile($fn, $finalFilePath, $job->gid, $job->cid, $type = 'application/pdf', $tag, $attachment = 0, $uid = $job->user_id, $ver, $job->job_type, $job->asset_id, $job->instance, $job->stamped, $job->stamp, $job->draft);
    logger(2, "doc_response_tag", "LogAndTagFile result: $attempt");

    $fields = [
      'completed'=>1,
      'completed_on'=>date('Y-m-d H:i:s'),
      'file_found' =>1,
      'file_found_on'=>date('Y-m-d H:i:s'),
    ];
    $db->update('omt_doc_jobs', $job->id, $fields);
    logger(2, "doc_response_update", "Job marked as completed");

    $notified = $db->query("SELECT notified FROM omt_doc_jobs WHERE id = ?", [$job->id])->first()->notified;
    if(isset($col) && $notified == 0){
        logger(2, "doc_response_notify", "Processing notification for job $job->id");
        $fields = [
            'cid'=>$job->cid,
            'gid'=>$job->gid,
            'asset_id'=>$attempt,
            $col=>$job->asset_id,
            'linked_by'=>$job->user_id,
            'linked_on'=>date('Y-m-d H:i:s'),
        ]; 
        $db->insert('omt_asset_generated_file_links', $fields);
        
        $docQ = $db->query("SELECT guid FROM omt_assets WHERE id = ?", [$attempt]);
        $docC = $docQ->count();
        if($docC < 1){
            logger(2, "doc_response_error", "Document not found in assets table: $attempt");
            logger("1","doc_response","Document not found in documents table. Cannot send notification. ID:". $attempt);
        }else{
            $doc = $docQ->first();
            $doc_guid = $doc->guid;
            
            $quick_link = $us_url_root."viewer/index.php?guid=$doc_guid&resource=file";
            $title = "Your document is ready";
            $message = "Your document is ready. You can view it <a target='_blank' href='".$quick_link."'>here</a>";
            logger(2, "doc_response_notify", "Sending notification to user $job->user_id for document $doc_guid");
            sendPlgMessage($job->user_id, $title, $message, $user_from = 0, $type = 3, $expires = "", $send_method = "standard");
            $db->update('omt_doc_jobs', $job->id, ['notified'=>1,'quick_link'=>$quick_link]);
            logger(2, "doc_response_notify", "Notification sent and job updated");
        }
    }
    logger(2, "doc_response_complete", "Process completed successfully");
    echo "success";
}



