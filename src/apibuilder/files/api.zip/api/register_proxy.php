<?php
/**
 * register_proxy.php  –  API endpoint for proxy enrolment
 * -------------------------------------------------------
 * Supports two flows:
 *
 * (1) Standard user/token enrolment
 *     → requires valid pairing token in omt_video_proxy_tokens
 *
 * (2) Silent internal registration
 *     → triggered by {"silent_register":true}
 *     → allowed only from IPs or Tailscale IPs listed in omt_servers_internal
 */

require_once '../users/init.php';
header('Content-Type: application/json');

logger(0, "proxy_register", "Register proxy API endpoint called", ["remote_addr" => Server::get('REMOTE_ADDR'), "request_method" => Server::get('REQUEST_METHOD')]);

// ---------------------------------------------------------------
// Enforce POST + JSON
// ---------------------------------------------------------------
if (Server::get('REQUEST_METHOD') !== 'POST') {
    logger(0, "proxy_register", "Request rejected: non-POST method", ["method" => Server::get('REQUEST_METHOD')]);
    http_response_code(405);
    echo json_encode(['error' => 'POST only']);
    exit;
}

$raw  = file_get_contents('php://input');
logger(0, "proxy_register", "Raw input received", ["raw_length" => strlen($raw)]);

$data = json_decode($raw, true);
if (!is_array($data)) {
    logger(0, "proxy_register", "Request rejected: invalid JSON", ["raw_input" => substr($raw, 0, 200)]);
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}
logger(0, "proxy_register", "JSON decoded successfully", ["data_keys" => array_keys($data)]);

// ---------------------------------------------------------------
// Extract core fields
// ---------------------------------------------------------------
$deviceId          = $data['device_id']          ?? '';
$pubkey            = $data['pubkey']             ?? '';
$token             = $data['token']              ?? '';
$incomingKey       = $data['incoming_key']       ?? '';
$silent            = !empty($data['silent_register']);

// Cloud server information (optional, for silent registrations)
$cloudServerId     = isset($data['cloud_server_id']) ? (int)$data['cloud_server_id'] : null;
$cloudRtmpPort     = isset($data['cloud_rtmp_port']) ? (int)$data['cloud_rtmp_port'] : null;
$cloudRtmpsPort    = isset($data['cloud_rtmps_port']) ? (int)$data['cloud_rtmps_port'] : null;
$cloudStreamKey    = $data['cloud_stream_key']   ?? null;

logger(0, "proxy_register", "Core fields extracted", [
    "device_id" => $deviceId,
    "pubkey_length" => strlen($pubkey),
    "token_length" => strlen($token),
    "incoming_key" => $incomingKey,
    "silent_register" => $silent,
    "cloud_server_id" => $cloudServerId,
    "cloud_rtmp_port" => $cloudRtmpPort,
    "cloud_rtmps_port" => $cloudRtmpsPort,
    "cloud_stream_key" => $cloudStreamKey
]);

// Basic field validation
if (
    !preg_match('/^[0-9A-Za-z\-]{3,64}$/', $deviceId) ||
    strlen($pubkey) < 40 ||
    !preg_match('/^stream-[A-Za-z0-9\-]{5,32}$/', $incomingKey)
) {
    logger(0, "proxy_register", "Request rejected: malformed payload", [
        "device_id_valid" => preg_match('/^[0-9A-Za-z\-]{3,64}$/', $deviceId) ? true : false,
        "pubkey_length" => strlen($pubkey),
        "incoming_key_valid" => preg_match('/^stream-[A-Za-z0-9\-]{5,32}$/', $incomingKey) ? true : false
    ]);
    http_response_code(400);
    echo json_encode(['error' => 'Malformed payload']);
    exit;
}
logger(0, "proxy_register", "Field validation passed");

// ===============================================================
// (A) Silent internal registration
// ===============================================================
if ($silent === true) {
    logger(0, "proxy_register", "Silent registration mode activated");

    $clientIp = Server::get('REMOTE_ADDR');
    logger(0, "proxy_register", "Client IP extracted", ["client_ip" => $clientIp]);

    // Confirm IP or tailscale_ip belongs to an active proxy server
    $q = $db->query(
        "SELECT * FROM omt_servers_internal
         WHERE active = 1 AND video_proxy = 1
           AND (ip = ? OR tailscale_ip = ?)",
        [$clientIp, $clientIp]
    );
    $c = $q->count();
    logger(0, "proxy_register", "Queried omt_servers_internal for IP authorization", ["query_count" => $c, "client_ip" => $clientIp]);

    if ($q->count() < 1) {
        logger(0, "proxy_register", "Silent registration rejected: unauthorized IP", ["client_ip" => $clientIp]);
        http_response_code(403);
        echo json_encode(['error' => 'Unauthorized silent registration', 'ip' => $clientIp]);
        exit;
    }
    logger(0, "proxy_register", "IP authorization passed for silent registration", ["client_ip" => $clientIp]);
    

    // Pull cid/gid if supplied
    $cid = isset($data['cid']) ? (int)$data['cid'] : 0;
    $gid = isset($data['gid']) ? (int)$data['gid'] : 0;
    logger(0, "proxy_register", "Silent registration: cid/gid extracted", ["cid" => $cid, "gid" => $gid]);

    // Insert or update proxy record
    $existingQ = $db->query("SELECT id FROM omt_video_proxy_devices WHERE device_id = ?", [$deviceId]);
    $existingC = $existingQ->count();
    logger(0, "proxy_register", "Checked for existing device", ["device_id" => $deviceId, "existing_count" => $existingC]);

    if ($existingC > 0) {
        $id = $existingQ->first()->id;
        logger(0, "proxy_register", "Updating existing device", ["device_id" => $deviceId, "record_id" => $id]);

        $updateData = [
            'cid'           => $cid,
            'gid'           => $gid,
            'pubkey'        => $pubkey,
            'incoming_key'  => $incomingKey,
            'status'        => 'active',
            'updated_at'    => date('Y-m-d H:i:s'),
            'registered_ip' => $clientIp,
            'registered_by' => 'auto',
        ];

        // Add cloud server fields if provided
        if ($cloudServerId !== null) {
            $updateData['cloud_server_id'] = $cloudServerId;
            $updateData['deployment_type'] = 'cloud';
        }
        if ($cloudRtmpPort !== null) {
            $updateData['cloud_rtmp_port'] = $cloudRtmpPort;
        }
        if ($cloudRtmpsPort !== null) {
            $updateData['cloud_rtmps_port'] = $cloudRtmpsPort;
        }
        if ($cloudStreamKey !== null) {
            $updateData['cloud_stream_key'] = $cloudStreamKey;
        }

        $db->update('omt_video_proxy_devices', $id, $updateData);
        logger(0, "proxy_register", "Device record updated successfully", ["device_id" => $deviceId, "record_id" => $id]);
        $msg = 'updated';
    } else {
        logger(0, "proxy_register", "Creating new device record", ["device_id" => $deviceId]);

        // Create a synthetic token for silent registration (to maintain JOIN compatibility)
        $syntheticToken      = 'auto-' . bin2hex(random_bytes(12));
        $syntheticTokenHash  = hash('sha256', $syntheticToken);
        $tokenExpiry         = date('Y-m-d H:i:s', strtotime('+30 days'));

        logger(0, "proxy_register", "Creating synthetic token for silent registration", ["token_hash" => substr($syntheticTokenHash, 0, 16) . "..."]);

        $db->insert('omt_video_proxy_tokens', [
            'cid'        => $cid,
            'gid'        => $gid,
            'token'      => $syntheticToken,
            'token_hash' => $syntheticTokenHash,
            'created_by' => 0, // 0 indicates auto-generated/system
            'expires_on' => $tokenExpiry,
            'used_on'    => date('Y-m-d H:i:s'), // Immediately mark as used
            'device_id'  => $deviceId,
            'created_on' => date('Y-m-d H:i:s'),
        ]);

        if ($db->error()) {
            logger(0, "proxy_register", "Failed to create synthetic token", ["error" => $db->errorString()]);
            http_response_code(500);
            echo json_encode(['error' => 'Database error during token creation']);
            exit;
        }

        $tokenId = $db->lastId();
        logger(0, "proxy_register", "Synthetic token created", ["token_id" => $tokenId]);

        // Now insert the device with the token_id
        $insertData = [
            'cid'           => $cid,
            'gid'           => $gid,
            'device_id'     => $deviceId,
            'pubkey'        => $pubkey,
            'incoming_key'  => $incomingKey,
            'token_id'      => $tokenId,
            'status'        => 'active',
            'registered_by' => 'auto',
            'registered_ip' => $clientIp,
            'registered_on' => date('Y-m-d H:i:s'),
        ];

        // Add cloud server fields if provided
        if ($cloudServerId !== null) {
            $insertData['cloud_server_id'] = $cloudServerId;
            $insertData['deployment_type'] = 'cloud';
        }
        if ($cloudRtmpPort !== null) {
            $insertData['cloud_rtmp_port'] = $cloudRtmpPort;
        }
        if ($cloudRtmpsPort !== null) {
            $insertData['cloud_rtmps_port'] = $cloudRtmpsPort;
        }
        if ($cloudStreamKey !== null) {
            $insertData['cloud_stream_key'] = $cloudStreamKey;
        }

        $db->insert('omt_video_proxy_devices', $insertData);
        $dbe = $db->errorString();

        logger(0, "proxy_register", "New device record created successfully $dbe", ["device_id" => $deviceId, "token_id" => $tokenId]);
        $msg = 'created';
    }

    if ($db->error()) {
        logger(0, "proxy_register", "Silent registration failed: database error", ["error" => $db->errorString()]);
        http_response_code(500);
        echo json_encode(['error' => 'Database error during silent registration']);
        exit;
    }

    logger(0, "proxy_register", "Silent registration completed successfully", [
        "action" => $msg,
        "device_id" => $deviceId,
        "cid" => $cid,
        "gid" => $gid,
        "client_ip" => $clientIp,
        "cloud_server_id" => $cloudServerId,
        "deployment_type" => $cloudServerId !== null ? 'cloud' : 'local'
    ]);

    $response = [
        'ok'      => true,
        'mode'    => 'silent',
        'action'  => $msg,
        'cid'     => $cid,
        'gid'     => $gid,
        'ip'      => $clientIp
    ];

    // Include cloud server info in response if provided
    if ($cloudServerId !== null) {
        $response['cloud_server_id'] = $cloudServerId;
        $response['deployment_type'] = 'cloud';
        $response['cloud_rtmp_port'] = $cloudRtmpPort;
        $response['cloud_rtmps_port'] = $cloudRtmpsPort;
        $response['cloud_stream_key'] = $cloudStreamKey;
    }

    echo json_encode($response);
    exit;
}

// ===============================================================
// (B) Standard token-based registration (existing flow)
// ===============================================================
logger(0, "proxy_register", "Standard token-based registration mode activated");

// Validate token format
if (strlen($token) < 20) {
    logger(0, "proxy_register", "Token validation failed: too short", ["token_length" => strlen($token)]);
    http_response_code(400);
    echo json_encode(['error' => 'Missing or invalid token']);
    exit;
}
logger(0, "proxy_register", "Token length validation passed", ["token_length" => strlen($token)]);

$tokenHash = hash('sha256', $token);
logger(0, "proxy_register", "Token hashed for lookup", ["token_hash" => substr($tokenHash, 0, 16) . "..."]);

// Look up unused, unexpired token
$currentTime = date("Y-m-d H:i:s");
$q = $db->query(
    "SELECT * FROM omt_video_proxy_tokens
     WHERE token_hash = ? AND used_on IS NULL AND expires_on > ?",
    [$tokenHash, $currentTime]
);
logger(0, "proxy_register", "Token lookup completed", ["query_count" => $q->count()]);

if ($q->count() < 1) {
    logger(0, "proxy_register", "Token validation failed: invalid or expired", ["token_hash" => substr($tokenHash, 0, 16) . "..."]);
    http_response_code(403);
    echo json_encode(['error' => 'Token invalid or expired']);
    exit;
}
$tok = $q->first();
logger(0, "proxy_register", "Valid token found", ["token_id" => $tok->id, "cid" => $tok->cid, "gid" => $tok->gid, "created_by" => $tok->created_by]);

// Insert new proxy device
logger(0, "proxy_register", "Attempting to insert new proxy device", [
    "device_id" => $deviceId,
    "cid" => $tok->cid,
    "gid" => $tok->gid,
    "token_id" => $tok->id,
    "registered_by" => $tok->created_by,
    "registered_ip" => Server::get('REMOTE_ADDR')
]);

$db->insert('omt_video_proxy_devices', [
    'cid'           => $tok->cid,
    'gid'           => $tok->gid,
    'device_id'     => $deviceId,
    'pubkey'        => $pubkey,
    'incoming_key'  => $incomingKey,
    'token_id'      => $tok->id,
    'status'        => 'active',
    'registered_by' => $tok->created_by,
    'registered_ip' => Server::get('REMOTE_ADDR'),
]);

if ($db->error()) {
    if (strpos($db->errorString(), 'Duplicate entry') !== false) {
        logger(0, "proxy_register", "Device registration failed: duplicate entry", ["device_id" => $deviceId, "error" => $db->errorString()]);
        http_response_code(409);
        echo json_encode(['error' => 'Device ID or Incoming Key already registered']);
    } else {
        logger(0, "proxy_register", "Device registration failed: database error", ["device_id" => $deviceId, "error" => $db->errorString()]);
        http_response_code(500);
        echo json_encode(['error' => 'Database error during device registration']);
    }
    exit;
}
logger(0, "proxy_register", "Device inserted successfully", ["device_id" => $deviceId]);

// Mark token as used
logger(0, "proxy_register", "Marking token as used", ["token_id" => $tok->id, "device_id" => $deviceId]);

$db->update('omt_video_proxy_tokens', $tok->id, [
    'used_on'   => date('Y-m-d H:i:s'),
    'device_id' => $deviceId,
]);

logger(0, "proxy_register", "Token marked as used successfully", ["token_id" => $tok->id]);

logger(0, "proxy_register", "Token-based registration completed successfully", [
    "device_id" => $deviceId,
    "token_id" => $tok->id,
    "cid" => $tok->cid,
    "gid" => $tok->gid
]);

echo json_encode(['ok' => true, 'mode' => 'token']);
