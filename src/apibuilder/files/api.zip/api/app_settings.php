<?php
require_once "../users/init.php";
$action = Input::get('action');
$response = [];

logger(1,"diag get",json_encode($_GET));
//Although this file is called app_settings, it has morphed into a semi-unauthenticated API
//Since all the standard API calls either require a username/password or an API key, this allows us to both
//offer unauthenticated APIs for basic API settings as well as some API calls that are authenticated by the licenseKey of the app itself.

//Most of these calls were originally direct sql calls from the app that have been migrated but happen before the user has officially logged in. Therefore we do not yet have the API key.

//There is currently no rate limiting on this API, but that might change.

//fetches the initial settings for the App.
//this call is wide open
if($action == "fetchAppSettings"){
  $update_types = [
    '0' => 'Unknown',
    '1' => 'Minor Update',
    '2' => 'Major Update',
    '3' => 'Critical Update',
];

$program_types = [
    '0' => 'Misc Download',
    '1' => 'Discussion Manager',
    '2' => 'Member Application',
    '3' => 'Public Display Application',
    '4' => 'Meeting Manager',
];

$release_types = [
    '0' => 'Unknown',
    '1' => 'Legacy',
    '2' => 'Beta',
    '3' => 'Official Release',
];
$new = $db->query("SELECT 
s.splash_bg_image_url,
CONCAT('https://cms.omt-appserver.com/l/?', l1.link_name) AS purchase_license_link,
CONCAT('https://cms.omt-appserver.com/l/?', l2.link_name) AS renew_license_link,
s.feature_info_link,
CONCAT('https://cms.omt-appserver.com/l/?', l3.link_name) AS default_support_link,
CONCAT('https://cms.omt-appserver.com/l/?', l4.link_name) AS default_release_notes_link,
CONCAT('https://cms.omt-appserver.com/l/?mm-release','') AS update_info_link,
CONCAT(s.url, '/users/forgot_password.php') AS forgot_password_link,
s.mm_track
FROM omt_servers s 
LEFT OUTER JOIN plg_links l1 ON s.purchase_license_link = l1.id
LEFT OUTER JOIN plg_links l2 ON s.renew_license_link = l2.id
LEFT OUTER JOIN plg_links l3 ON s.default_support_link = l3.id
LEFT OUTER JOIN plg_links l4 ON s.default_release_notes_link = l4.id
WHERE s.id = ?"

,[$server_id])->first();
$new = fetchThisServerDownloadInfo($new);

    // $new->update_info_title = "A software update is available";
    // $new->update_info_copy = "A new version of the software is available. Please update to the latest version to ensure you have the latest features and bug fixes.";
    // $new->update_info_button_title = "Install the latest update";
    // $new->update_info_link = "https://cms.omt-appserver.com/l/?mm-release";
    // $new->feature_info_button_title = "Latest release notes";



      $response['success'] = true;
      $response['devMessage'][] = "Settings fetched";
      $response['settings'] = $new;
 
  echo json_encode($response); die;
}


$licenseKey = Input::get("licenseKey");
if($licenseKey != ""){
  $q = $db->query("SELECT * FROM omt_customers WHERE licenseKey = ?",[$licenseKey]);
  $c = $q->count();
  if($c < 1){
    $response['devMessage'][] = "Invalid license key";
    echo json_encode($response); die;
  }else{
    $customer = $q->first();
  }
}

//CALLS BELOW THIS POINT REQUIRE A VALID licenseKey and the customer will be validated against that key
if($action == "fetchCustomerByLicense"){
  $response['data'] = [];
  if(!isset($licenseKey) || $licenseKey == ""){
    $response['devMessage'][] = "License not provided";
    echo json_encode($response);die;
  }

  $q = $db->query("SELECT
    omt_customers.*,
    omt_licensetypes.pro,
    omt_licensetypes.has_documents,
    omt_licensetypes.has_comments,
    omt_licensetypes.has_av
    FROM omt_customers
    INNER JOIN omt_licensetypes
    ON omt_customers.licenseType = omt_licensetypes.id
    WHERE omt_customers.licenseKey = ?",
    [$licenseKey]);
    $c = $q->count();
    if($c < 1){
      $response['devMessage'][] = "Customer not found";
    }else{
      $response['data'] = $q->results(true);
    
      $response['admins'] = $db->query("SELECT email FROM view_customer_admins WHERE custId = ? ",[$response['data'][0]['id']])->results();
      $response['success'] = true;
    }
    echo json_encode($response); die;
  }


  if($action == "updateInstallation"){
    $custId = Input::get("custId");
    $fields = [];
    $data = [];
    $anyData = false;
    //get the customer id from the authentication, not the incoming api data
    if(!isset($custId) || $custId != $customer->id){
      $response['devMessage'][] = "This user or licenseKey does not belong to a customer, so we cannot store this installation";
      echo json_encode($response);die;
    }

    $columns = ["machineKey","active","origInstallDate","lastUpdatedDate","currentVersion","lastAccessDate","deviceName","operatingSystem","processorInfo","RAM","custId", "deviceNickname"];
    foreach($columns as $c){
    $data[$c] = Input::get($c);
      if($data[$c] != ""){
        $anyData = true;
        $fields[$c] = $data[$c];
      }
    }
    $q = $db->query("SELECT * FROM omt_mm_installations WHERE machineKey = ? AND custId = ?",[$data['machineKey'],$custId]);
    $c = $q->count();
    if($c > 0){
      $keyFound = true;
      $f = $q->first();
    }else{
      $keyFound = false;
    }

    if($anyData){
      if($keyFound){
        $response['devMessage'][] = "Installation updated";
        $unset = ['origInstallDate', 'lastUpdatedDate'];
        foreach($unset as $u){
          if(isset($fields[$u])){
            $response['devMessage'][] = "Ignoring " . $u;
            unset($fields[$u]);

          }
        }
        $db->update("omt_mm_installations",$f->id,$fields);
      }else{
        $response['devMessage'][] = "Installation created";
        $db->insert("omt_mm_installations",$fields);
      }

    }else{
      $response['devMessage'][] = "No valid data fields submitted";
    }

    if(!$db->error()){
      $response['devMessage'][] = "Received ".count($fields)." fields of a possible ".count($columns).".";
      $response['success'] = true;
    }else{
      $response['devMessage'][] = "DB Error ".$db->errorString();
    }
    echo json_encode($response);die;
  }

  if($action == "fetchCustomersByCode"){
    $response['data'] = [];
    $code = Input::get('custCode');
    if($code == ""){
      $response['devMessage'][] = "Customer code not provided";
      echo json_encode($response);die;
    }

    if($code != $customer->custCode){
      $response['devMessage'][] = "Customer code does not match license key";
      echo json_encode($response);die;
    }

    $q = $db->query("SELECT DISTINCT
      omt_customers.id,omt_customers.custName,omt_customers.custCode,users.id,users.email,users.username,
      users.fname,users.lname,user_permission_matches.user_id,user_permission_matches.permission_id
      FROM omt_customers
      INNER JOIN omt_cust_user_map ON omt_cust_user_map.custId = omt_customers.id
      INNER JOIN users ON omt_cust_user_map.userId = users.id
      INNER JOIN user_permission_matches ON users.id = user_permission_matches.user_id
      INNER JOIN permissions ON user_permission_matches.permission_id = permissions.id
      WHERE omt_customers.id = ? AND omt_customers.custCode =  ?",[$customer->id,$code]);

    $c = $q->count();
    if($c < 1){
      $response['devMessage'][] = "No data found";
    }else{
      $response['data'] = $q->results(true);
      $response['success'] = true;
    }
    echo json_encode($response);die;
  }


//This call is currently in both the app_settings.php and migrated_calls.php
  if($action == "fetchCustomerGroup"){
    $response['data'] = [];
    $user_id = Input::get('user_id');
    if(!is_numeric($user_id)){
      $response['devMessage'][] = "Non numeric user id supplied";
    }

    $c = $db->query("SELECT * FROM omt_cust_user_map WHERE custID = ? AND userID = ?",[$customer->id,$user_id])->count();
    if($c < 1){
      $response['devMessage'][] = "The user id does not match the license key";
      echo json_encode($response);die;
    }
    $q = $db->query("SELECT
      omt_groups.id,
      omt_groups.groupName,
      omt_groups.groupFolderCode
      FROM users
      INNER JOIN omt_user_group_map
      ON omt_user_group_map.userId = users.id
      INNER JOIN omt_groups
      ON omt_user_group_map.groupId = omt_groups.id
      WHERE users.id = ?",[$user_id]);
    $c = $q->count();
    if($c < 1){
      $response['devMessage'][] = "No data found";
    }else{
      $response['data'] = $q->results(true);
      $response['success'] = true;
    }
    echo json_encode($response);die;
  }

//request the initial token for a webview login using licenseKey
  if($action == "requestWebviewLogin"){
    logger("1","api","requestWebviewLogin");
    if(!isset($customer)){
      die; //license key was never validated  
    }
    $response['data'] = [];
    $responseKey = Input::get('responseKey');
    if($responseKey == ""){
      $response['devMessage'][] = "Response key not provided";
      echo json_encode($response);die;
    }
    if(strlen($responseKey) != 32){
      $response['devMessage'][] = "Response key did not meet specification";
      echo json_encode($response);die;
    }
    //Check for duplicate responseKey whose expiration has not passed
    $c = $db->query("SELECT * FROM omt_api_webview_requests WHERE responseKey = ? AND cid = ? AND 
    expires < now()",[$responseKey,$customer->id])->count();

    if($c > 0){
      $response['devMessage'][] = "Response key cannot be validated";
      echo json_encode($response);die;
    }

    //provide a token that will be used to authenticate the user
    $token = md5(uniqid($responseKey,true));
    $expires = date('Y-m-d H:i:s',strtotime('+30 minutes'));
    $app_version = Input::get('version');
    $application = Input::get('app');
    $fields = [
      'cid' => $customer->id,
      'responseKey' => $responseKey,
      'token' => $token,
      'ip' => ipCheck(),
      'expires' => $expires,
      'app_version' => $app_version,
      'app' => $application,
    ];
    $db->insert('omt_api_webview_requests',$fields);

    $response['data']['token'] = $token;
    $response['success'] = true;
    $response['data']['url'] = $actual_site_url . "/webview/requestLogin/index.php?token=$token&custId=".$customer->id;
    $response['devMessage'][] = "Token expires at $expires";
    
    echo json_encode($response);die;
  }