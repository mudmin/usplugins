<?php 
require_once "../users/init.php";
$servers = $db->query("SELECT `url` FROM omt_servers where active = 1 AND production = 1")->results();
echo json_encode($servers);die;