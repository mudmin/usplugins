<?php
require_once "../users/init.php";
$code = Input::get('code');
$validCode = "VocKbKd7B0b7e";
if($code != $validCode){
  die("np - " . $code);
}


$ip = ipCheck();
require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if(!hasPerm(2) && !in_array($ip, $valid_sync_ips) && $code != $validCode){
  die("np - hp2");
}

include $abs_us_root . $us_url_root . "api/cron_fetch_content.php";
include $abs_us_root . $us_url_root . "api/cron_fetch_language.php";


$zeros = $db->query("SELECT * FROM omt_ma_devices WHERE cid = 0 AND current_group > 0")->results();
if(count($zeros) > 0){
  $groups = $db->query("SELECT id, customerId FROM omt_groups")->results();
  $map = [];
  foreach($groups as $g){
    $map[$g->id] = $g->customerId;
  }
  foreach($zeros as $z){
    if(isset($map[$z->current_group])){
      $db->update("omt_ma_devices",$z->id,["cid"=>$map[$z->current_group]]);
    }else{
      $db->update("omt_ma_devices",$z->id,["cid"=>-1]);
    }
  }
}


logger(1,"Daily Cron","Accepted");
//180 day logs
$logdate = date("Y-m-d",strtotime("- 180 days",strtotime(date("Y-m-d"))));
$tables = [
  // "omt_agenda_audit"=>"ts",
  // "omt_user_audit"=>"dt",
  "logs"=>"logdate",
  "audit"=>"timestamp",
  "logs_troublemakers"=>"ts",
];

foreach($tables as $table=>$column){
  $db->query("DELETE FROM $table WHERE $column < ?",[$logdate]);
}

$cust = $db->query("SELECT id FROM omt_customers")->results();

foreach($cust as $c){
  $attempt = generateCustomerSupportUser($c->id);
  lidump($attempt);
}

// //14 day logs
// $logdate = offsetDate(-14);
// $db->query("DELETE FROM logs_api WHERE ts < ?",[$logdate]);
//testing new api log archiver
if(!isset($logArchiver)) { 
  $logArchiver = new LogArchiver(); 
}

// Use it for API logs
$apiLogConfig = [
  'table' => 'logs_api',
  'query' => "SELECT l.*, u.fname, u.lname 
              FROM logs_api AS l 
              LEFT OUTER JOIN users AS u ON l.user_id = u.id 
              WHERE DATE(l.ts) = ?",
  'folder' => 'api_logs',
  'date_field' => 'ts',
  'days_to_keep' => 10
];
$logArchiver->archiveLogs($apiLogConfig);

$path = $abs_us_root . $us_url_root . "customerdata/meetings/downloads/";

//handle the zip files
if ($handle = opendir($path)) {
    while (false !== ($file = readdir($handle))) {
      if($file == "." || $file == ".." || $file == ".htaccess" || $file == "tmp") { continue; }

        $filelastmodified = filemtime($path . $file);
        //24 hours in a day * 3600 seconds per hour
        if((time() - $filelastmodified) > 24*3600){
           unlink($path . $file);
        }
    }
    closedir($handle);
}

//delete old intensive api logs
$path = $abs_us_root . $us_url_root . "logs/";

if ($handle = opendir($path)) {
    while (false !== ($file = readdir($handle))) {
      if($file == "." || $file == ".." || $file == ".htaccess" || $file == "tmp") { continue; }

        $filelastmodified = filemtime($path . $file);
        //1 day = 24 hours in a day * 3600 seconds per hour
        if((time() - $filelastmodified) > 24 * 3600 * 7){
           unlink($path . $file);
        }
    }
    closedir($handle);
}

// $q = $db->query("SELECT * FROM omt_groups WHERE aqid > 0")->results();
// dnd($q);
// fetchAQMeetings($group, $all = false)
$paths = [
  $abs_us_root . $us_url_root . "customerdata/meetings/downloads/tmp/",
  $abs_us_root . $us_url_root . "takeout/tmp/",
  $abs_us_root . $us_url_root . "uploads/",
];
foreach($paths as $path){
if ($handle = opendir($path)) {
    while (false !== ($file = readdir($handle))) {
      if($file == "." || $file == ".." || $file == ".htaccess" || $file == "tmp") { continue; }

      deleteTmpOMTDir($path);
    }
    closedir($handle);
}
}

$today = date("Y-m-d");
$groups = $db->query("SELECT id FROM omt_groups WHERE temp_config_id > 0 AND temp_users_expire < ?",[$today])->results();
foreach($groups as $g){
  logger(1,"Purging Tech Check","Purging Tech Check Group ".$g->id);
  echo "Purging Tech Check Group ".$g->id;
  purgeGroupTemp($g->id);
}



function deleteTmpOMTDir($dirPath) {
    if (! is_dir($dirPath)) {
        throw new InvalidArgumentException("$dirPath must be a directory");
    }
    if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
        $dirPath .= '/';
    }
    $files = glob($dirPath . '*', GLOB_MARK);
    foreach ($files as $file) {
        if (is_dir($file) && $file != "tmp") {

          deleteTmpOMTDir($file);
        } else {
            unlink($file);
        }
    }
    // rmdir($dirPath);
}

//clean up configs to make sure the meeting has a valid config
$meetings = $db->query("SELECT id, _gid, _config FROM omt_meetings WHERE _gid > 0 AND _config > 0")->results();
foreach($meetings as $m){
    $config = $db->query("SELECT id FROM omt_configs WHERE id = ? AND gid = ?",[$m->_config,$m->_gid])->count();
    if($config < 1){
        // lidump("Meeting ".$m->id." has a bad config ".$m->_config);
        $db->update("omt_meetings",$m->id,["_config"=>0]);
    }
}

fixProblematicUsers();

$users = $db->query("SELECT DISTINCT uid, gid, cid, _imagePath
FROM omt_configs_persons
WHERE uid > 0 AND _imagePath NOT LIKE '%:\\%' ORDER BY id desc")->results();
foreach($users as $u){
    $safeCid = (int)$u->cid;
    $safeGid = (int)$u->gid;
    $safeUid = (int)$u->uid;
    $safeImagePath = basename($u->_imagePath);

    $base = $abs_us_root . $us_url_root . "customerdata/assets/" . $safeCid . "/" . $safeGid . "/";
    $profileDir = $abs_us_root . $us_url_root . "customerdata/assets/" . $safeCid . "/customer_profile_pics/";

    if(file_exists($base . $safeImagePath)){
        if(!is_dir($profileDir)){
            mkdir($profileDir, 0755, true);
        }
        copy($base . $safeImagePath, $profileDir . $safeUid . ".jpg");
    }else{
        // lidump("missing");
    }
}

//clean up the takeout tmp
$purge = ['takeout/tmp/'];
foreach($purge as $dir){
  $dir = $abs_us_root . $us_url_root . $dir;
//recursively delete directory
    if(is_dir($dir)){
        $files = array_diff(scandir($dir), array('.','..'));
        foreach ($files as $file) {
            $safeFile = basename($file);
            $fullPath = $dir . $safeFile;
            (is_dir($fullPath)) ? delTree($fullPath) : unlink($fullPath);
        }
        rmdir($dir);
    }

  if(!is_dir($dir)){
    mkdir($dir, 0755, true);
    //write .htaccess
    $htaccess = $dir . ".htaccess"; // Specify the file name

    $file = fopen($htaccess, "w");
    fwrite($file, "Options -Indexes");
    fclose($file);
  }
}
if($server_tag == "portal"){
fetchZohoCRM(false,"Contacts");
}

//insert new stats
$cust = $db->query("SELECT id from omt_customers WHERE active = 1 AND no_stats = 0")->count();
$grp = $db->query("SELECT id from omt_groups WHERE active = 1")->count();

$meet = $db->query("SELECT x.id from omt_meetings x
LEFT OUTER JOIN omt_customers c on c.id = x._cid
WHERE x._deleted = 0 AND x._template = 0 AND c.active = 1")->count();

$ai = $db->query("SELECT x.id FROM omt_agenda_items x 
LEFT OUTER JOIN omt_customers c on c.id = x._cid
WHERE x._deleted = 0 AND c.active = 1")->count();


$min = $db->query("SELECT x.id 
FROM omt_meeting_minute_instance x 
LEFT OUTER JOIN omt_meetings m on m.id = x._mid
LEFT OUTER JOIN omt_customers c on c.id = m._cid
WHERE  c.active = 1 ")->count();


//use this section to fix anything with all groups
$all = $db->query("SELECT * FROM view_customer_groups")->results();
foreach($all as $a){
    $cid = $a->customerId;
    $gid = $a->group_id;
    if($cid < 1 || $gid < 1 || $cid == null || $gid == null){
        continue;
    }

        // check for rooms
        $rooms = $db->query("SELECT id FROM omt_configs_rooms WHERE gid = ?",[$gid])->count();
        if($rooms < 1){
            $fields =
            [
                "gid"=>$gid,
                "cid"=>$cid,
                "room_name"=>"default",
                "created_by"=>0,
                "created_on"=>date("Y-m-d H:i:s"),
                 "default_room"=>1,
            ];
            $db->insert("omt_configs_rooms",$fields);
            echo "Inserted default room for group $gid ".$db->errorString()."<br>";
        }

        // check for configs
        $configs = $db->query("SELECT id FROM omt_configs WHERE gid = ?",[$gid])->count();
        if($configs < 1){
            $attempt = createNewConfig($cid,$gid,$roster = 0,$name = "Default Config", $default = true);
            echo "Inserted default config for group $gid <br>";
            dump($attempt);
        }
       

        $check = $db->query("SELECT id FROM omt_agenda_configs WHERE gid = ? AND cid = ?", [$gid, $cid])->count();

        if($check < 1){
            $fields = [
                'gid' => $gid,
                'cid' => $cid,
                'archived' => 0,
                'created_on' => date("Y-m-d H:i:s"),
                '_configName' => "Initial Config",
                '_defaultConfig' => 1
            ];
            $db->insert("omt_agenda_configs", $fields);
     
            echo "Inserted default agenda config for group $gid <br>" . $db->errorString()."<br>";

        }

        $check = $db->query("SELECT id FROM omt_meeting_minute_configs WHERE gid = ? AND cid = ?", [$gid, $cid])->count();
        if($check < 1){
            $fields = [
                'gid' => $gid,
                'cid' => $cid,
                'created_on' => date("Y-m-d H:i:s"),
                '_configName' => "Initial Config",
                '_defaultConfig' => 1,
        
            ];
            $db->insert("omt_meeting_minute_configs", $fields);
            echo "Inserted default meeting minute config for group $gid <br>" . $db->errorString()."<br>";
        
        }
   
}
//end group checks


//users
$acc = $db->query("SELECT 
u.id
FROM users u
LEFT OUTER JOIN omt_customers c on c.id = u.cid
WHERE u.permissions = 1 AND c.active = 1")->count();

// omt_api_sessions keyed to user_id active check

$mm = $db->query("SELECT s.id 
from omt_api_sessions s 
LEFT OUTER JOIN users u on u.id = s.user_id
LEFT OUTER JOIN omt_customers c on c.id = u.cid
WHERE s.active = 1 AND c.active = 1 AND u.permissions = 1")->count();
lidump($db->errorString());


$mtg = $db->query("SELECT s.id 
from omt_api_sessions s 
LEFT OUTER JOIN users u on u.id = s.user_id
LEFT OUTER JOIN omt_customers c on c.id = u.cid
WHERE s.active = 1 AND c.active = 1 AND u.permissions = 1 AND meeting_lock > 0")->count();
cleanupSecurityLogs($daysToKeep = 14);
$badge = $db->query("SELECT 
b.id
from plg_badges_match b
LEFT OUTER JOIN users u on u.id = b.user_id
LEFT OUTER JOIN omt_customers c on c.id = u.cid
WHERE c.active = 1 AND u.permissions = 1")->count();

lidump($db->errorString());

$db->insert('omt_support_stats',['ts'=>date("Y-m-d H:i:s"),'dt'=>date("Y-m-d"),'cust'=>$cust,'grp'=>$grp,'meet'=>$meet,'ai'=>$ai,'min'=>$min,'acc'=>$acc,'mm'=>$mm,'mtg'=>$mtg,'badge'=>$badge]);

if($server_tag == "dev" || $server_tag == "portal"){
$twentyFourHoursAgo = date("Y-m-d H:i:s", strtotime("-24 hours"));
$bugReportsQ = $db->query("SELECT
    l.id AS log_id,
    l.ts AS timestamp,
    u.fname,
    u.lname,
    u.email,
    l.debug,
    SUBSTRING(JSON_UNQUOTE(JSON_EXTRACT(l.incoming, '$.error')), 1, 1000) AS error,
    SUBSTRING(JSON_UNQUOTE(JSON_EXTRACT(l.incoming, '$.details')), 1, 1000) AS error_excerpt
FROM
    logs_api l
JOIN
    users u ON l.user_id = u.id
WHERE
    l.apicall = 'bugReport'
    AND l.ts >= ?
ORDER BY
    l.ts DESC", [$twentyFourHoursAgo]);

$bugReportsC = $bugReportsQ->count();
if($bugReportsC > 0){
$bugReports   = $bugReportsQ->results();
$subject      = ucfirst($server_tag) . " OMT Bug Reports in the last 24 hours";
$message      = "<h1>".ucfirst($server_tag)." OMT Bug Reports</h1>";
$message     .= "<p>There have been {$bugReportsC} bug reports in the last 24 hours.</p>";
$message     .= "<table border='1' cellpadding='4' cellspacing='0'>
  <tr>
    <th>Timestamp</th>
    <th>User</th>
    <th>Email</th>
    <th>Error</th>
    <th>Details</th>
    <th>Debug</th>
  </tr>";

// helper to cut off after the second dash
$truncateAfterSecondDash = function(string $text): string {
    $first  = strpos($text, '-');
    if ($first === false) return $text;
    $second = strpos($text, '-', $first + 1);
    if ($second === false) return $text;
    // include the second dash itself
    return substr($text, 0, $second + 1);
};

foreach ($bugReports as $b) {
    // escape everything first
    $ts      = hed($b->timestamp);
    $name    = hed("{$b->fname} {$b->lname}");
    $email   = hed($b->email);
    $error   = hed($b->error);
    $excerpt = hed($b->error_excerpt);
    $debug   = hed($b->debug);

    // if it's a Bad Password report, cut off after the second dash
    if (stripos($error, 'Bad Password') !== false) {
        $excerpt = $truncateAfterSecondDash($excerpt);

    }

    $message .= "
    <tr>
      <td>{$ts}</td>
      <td>{$name}</td>
      <td>{$email}</td>
      <td>{$error}</td>
      <td>{$excerpt}</td>
      <td>{$debug}</td>
    </tr>";
}
  $message .= "</table>"; 
  email("jeff@redzonestudios.com",$subject,$message);
  email("mudmin@gmail.com",$subject,$message);
  email("chad.trice@openmeetingtech.com",$subject,$message);
}

}

