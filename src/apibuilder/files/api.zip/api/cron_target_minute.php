<?php
define('USERSPICE_DO_NOT_LOG', true);
require_once "../users/init.php";
$code = Input::get('code');
// logger(1,"Cron target minute", "code: $code");
if($code != "VocKbKd7B0b7e"){
  logger(1,"Cron target minute", "Invalid code provided. Access denied.");
  die("np");
}

$ip = ipCheck();

//auto close kiosks
$currentTime = date("Y-m-d H:i:s");
$db->query("UPDATE omt_kiosks SET kiosk_active = 0 WHERE kiosk_active = 1 AND kiosk_closes < ?", [$currentTime]);

if(!isset($user) && !hasPerm(2)){
  require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
  if(!hasPerm(2) && !in_array($ip, $valid_sync_ips)){
    logger(1,"Cron target minute", "Invalid IP address. Access denied.");
    die("np");
  }
}
require_once $abs_us_root . $us_url_root . "admin/functions/meetings.php";


$ready = $db->query("SELECT id FROM omt_meeting_minute_instance WHERE processed = 0 AND ready_to_process = 1")->results();
foreach($ready as $r){
  createMeetingNoteData($r->id);
}

//disable stale session locks
$threeMinutesAgo = date("Y-m-d H:i:s", strtotime("-3 minutes"));
$db->query("UPDATE omt_api_sessions
SET active = 0, meeting_lock = null, config_lock = null, group_id = null
WHERE active = 1
AND last_heartbeat < ?", [$threeMinutesAgo]);

summarizeDevicePings(10);


// First, update expired jobs
$now = date("Y-m-d H:i:s");
$tenMinutesAgo = date("Y-m-d H:i:s", strtotime("-10 minutes"));
$expired = $db->query("UPDATE omt_doc_jobs
SET completed = 1,
    failed = 1,
    failed_msg = CONCAT('Document creation timed out. Created: ', created_on, ' Timed out: ', ?),
    completed_on = ?
WHERE created_on < ?
  AND completed = 0", [$now, $now, $tenMinutesAgo]);
if($expired->count() > 0){
logger(1, "doc_response", "Expired jobs: because of timeout $now " . $expired->count());
}
// Then, process jobs that need fetching
$jobs = $db->query("SELECT 
j.*,
jt.job_type as job_type_name
FROM omt_doc_jobs j 
LEFT OUTER JOIN omt_doc_job_types jt ON j.job_type = jt.id
WHERE j.fetch_later = 1 AND j.fetch_attempts < 10 AND j.completed = 0")->results();


foreach($jobs as $j){

  $job = $j;
  $asset_id = $job->asset_id;
  $api_job_id = $job->api_job_id;
  $remote_document_server = $job->remote_document_server;
  $remote_document_path = $job->remote_document_path;
  
  $j->fetch_attempts++;
  $db->update('omt_doc_jobs', $j->id, ['fetch_attempts' => $j->fetch_attempts]);

  
  if($j->fetch_attempts >= 7){
    $db->update('omt_doc_jobs', $j->id, [
      'completed' => 1, 
      'failed' => 1, 
      'failed_msg' => 'Failed to fetch document after 10 attempts'
    ]);
    
    continue;
  }
  
  // Fetch file
  $tempBasePath = $abs_us_root . $us_url_root . 'customerdata/tmp/pdf/';
  if (!is_dir($tempBasePath)) {
    mkdir($tempBasePath, 0755, true);
  }
  $tempFilePath = $tempBasePath . uniqid() . '.pdf';

  $safeCid = (int)$job->cid;
  $safeGid = (int)$job->gid;
  $safeAssetId = (int)$asset_id;
  $safeApiJobId = preg_replace('/[^a-zA-Z0-9_-]/', '', $api_job_id);
  $safeJobTypeName = preg_replace('/[^a-zA-Z0-9_-]/', '', $job->job_type_name);

  $basePath = $abs_us_root . $us_url_root . 'customerdata/assets/' . $safeCid . '/' . $safeGid . '/';
  if (!is_dir($basePath)) {
    mkdir($basePath, 0755, true);
  }

  $fn = $safeJobTypeName . "_" . $safeAssetId . "_" . $safeApiJobId . '.pdf';
  $finalFilePath = $basePath . $fn;

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $remote_document_server . $remote_document_path);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch, CURLOPT_TIMEOUT, 60);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
  curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36');

  // Open file handler for temporary file
  $fileHandler = fopen($tempFilePath, 'wb');
  if ($fileHandler === false) {
    logger(1, "doc_response", "Failed to open temporary file");
    continue;
  }
  curl_setopt($ch, CURLOPT_FILE, $fileHandler);

  // Execute cURL
  $resp = curl_exec($ch);
  $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

  curl_close($ch);
  fclose($fileHandler);

  if ($httpCode == 404) {
    logger(1, "doc_response", "CRON File not found on remote server - ".$remote_document_server . $remote_document_path);
    unlink($tempFilePath);
    continue;
  } elseif ($httpCode >= 400) {
    logger(1, "doc_response", "CRON HTTP error: " . $httpCode);
    unlink($tempFilePath);
    continue;
  } elseif (curl_errno($ch)) {
    logger(1, "doc_response", "CRON cURL error: " . curl_error($ch));
    unlink($tempFilePath);
    continue;
  }

  // Move temporary file to final location
  if (!rename($tempFilePath, $finalFilePath)) {
    logger(1, "doc_response", "Failed to move file to final location");
    continue;
  } else {
    $fields = [
      'completed' => 1,
      'completed_on' => date('Y-m-d H:i:s'),
      'file_found' => 1,
      'file_found_on' => date('Y-m-d H:i:s'),
      'fetch_later' => 0  // Add this line to prevent future attempts
    ];
    $db->update('omt_doc_jobs', $job->id, $fields);
    
    $ver = 0;
    if ($job->job_type == 1 || $job->job_type == 3) {
      $col = "mid";
      $tag = '6';
      $ver = $db->query("SELECT * FROM omt_doc_jobs WHERE asset_id = ? AND (job_type = 1 OR job_type = 3) AND completed = 1", [$job->asset_id])->count();
    } elseif ($job->job_type == 2 || $job->job_type == 4) {
      $tag = '7';
      $col = "instance";
      $ver = $db->query("SELECT * FROM omt_doc_jobs WHERE asset_id = ? AND (job_type = 2 OR job_type = 4) AND completed = 1", [$job->asset_id])->count();
    }
    
    $attempt = logAndTagFile($fn, $finalFilePath, $job->gid, $job->cid, $type = 'application/pdf', $tag, $attachment = 0, $uid = $job->user_id, $ver, $job->job_type, $job->asset_id, $job->instance, $job->stamped, $job->stamp, $job->draft);

    $notified = $db->query("SELECT notified FROM omt_doc_jobs WHERE id = ?", [$job->id])->first()->notified;
    if(isset($col) && $notified == 0){
      $fields = [
        'cid' => $job->cid,
        'gid' => $job->gid,
        'asset_id' => $attempt,
        $col => $job->asset_id,
        'linked_by' => $job->user_id,
        'linked_on' => date('Y-m-d H:i:s'),
      ];
      $db->insert('omt_asset_generated_file_links', $fields);
      
      $docQ = $db->query("SELECT guid FROM omt_assets WHERE id = ?", [$attempt]);
      $docC = $docQ->count();
      if($docC < 1){
        logger("1","doc_response","Document not found in documents table. Cannot send notification. ID:". $attempt);
      } else {
        $doc = $docQ->first();
        $doc_guid = $doc->guid;
        $quick_link = $us_url_root."viewer/index.php?guid=$doc_guid&resource=file";
        $title = "Your document is ready";
        $message = "Your document is ready. You can view it <a target='_blank' href='".$us_url_root."viewer/index.php?guid=$doc_guid&resource=file'>here</a>";
        sendPlgMessage($job->user_id, $title, $message, $user_from = 0, $type = 3, $expires = "", $send_method = "standard");
        $db->update('omt_doc_jobs', $job->id, ['notified' => 1,'quick_link'=>$quick_link]);
      }
    }
    logger(1, "doc_response", "File processed successfully for job ID: " . $job->id);
  }
}

// //make sure we wait a full cron cycle before processing minutes to be sure they're fully uploaded
// $mark = $db->query("UPDATE omt_meeting_minute_instance SET ready_to_process = 1 WHERE ready_to_process = 0 AND processed = 0 AND practice = 0");

// Auto-stop expired preview streams
// require_once $abs_us_root . $us_url_root . 'customers/video/functions/vimeo_live_functions.php';

// $currentTime = date("Y-m-d H:i:s");
// $expiredTargets = $db->query("
//     SELECT DISTINCT t.proxy_id, d.device_id
//     FROM omt_video_proxy_targets t
//     JOIN omt_video_proxy_devices d ON t.proxy_id = d.id
//     WHERE t.auto_stop_at IS NOT NULL
//     AND t.auto_stop_at <= ?
//     AND t.stop_streaming = 0", [$currentTime])->results();

// foreach ($expiredTargets as $target) {
//     $result = stopProxyStreaming($target->proxy_id);
//     if ($result['success']) {
//         logger(1, "proxy_auto_stop", "Auto-stopped preview for device: " . $target->device_id);
//     } else {
//         logger(1, "proxy_auto_stop", "Failed to auto-stop device " . $target->device_id . ": " . $result['message']);
//     }
// }
