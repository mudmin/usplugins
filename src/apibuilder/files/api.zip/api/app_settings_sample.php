<?php
require_once "../users/init.php";
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
?>
<div class="row mt-3">
    <div class="col-6">
        <?php $orig = $db->query("SELECT * FROM omt_app_mm_load_settings")->first(); 
        foreach($orig as $k=>$v){ 
            echo $k." --- ".$v."<br>";} ?>
        
    </div>
    <div class="col-6">
        <?php 
        $update_types = [
            '0' => 'Unknown',
            '1' => 'Minor Update',
            '2' => 'Major Update',
            '3' => 'Critical Update',
        ];
        
        $program_types = [
            '0' => 'Misc Download',
            '1' => 'Discussion Manager',
            '2' => 'Member Application',
            '3' => 'Public Display Application',
            '4' => 'Meeting Manager',
        ];
        
        $release_types = [
            '0' => 'Unknown',
            '1' => 'Legacy',
            '2' => 'Beta',
            '3' => 'Official Release',
        ];


        $new = $db->query("SELECT 
        s.splash_bg_image_url,
        s.purchase_license_link,
        s.renew_license_link,
        s.feature_info_link,
        s.default_support_link,
        s.default_release_notes_link,
        CONCAT(s.url, '/users/forgot_password.php') AS forgot_password_link,
        s.mm_track
        
        FROM omt_servers s 
        WHERE s.id = ?",[$server_id])->first();
    



        $new = fetchThisServerDownloadInfo($new);
        foreach($new as $k=>$v){ 
            echo $k." --- ".$v."<br>";;
            }
        ?>

</div>
    </div>


<?php
die;