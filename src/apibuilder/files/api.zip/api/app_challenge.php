<?php
if(!isset($_GET['request']) || !isset($_GET['code']) || $_GET['request'] != "T2MEaucwKZ4d8hKgwK"){
    die("");
}

$noMaintenanceRedirect = true;
require_once "../users/init.php";

$ip = ipCheck();
$resp = ["success"=>false, "msg"=>"", "uid"=>0, "response_code"=>""];
$code = strtolower(Input::get('code'));
//break code into parts. 
$last5 = substr($code, -5);
$group = substr($code, 0, -5);
$gid = substr($group, 1);
$gQ = $db->query("SELECT * FROM omt_groups WHERE id = ?",[$gid]);
$gC = $gQ->count();
if($gC < 1){
    $resp["msg"] = "Group not found";
    $fields = [
        'gid'=>$gid,
        'challenge'=>$last5,
        'msg'=>"Group not found",
        'success'=>0,
        'ip'=>$ip,
        'ts'=>date("Y-m-d H:i:s"),
    ];
    $db->insert('omt_app_challenge_logs',$fields);
    echo json_encode($resp);
    die();
}
$g = $gQ->first();
if($g->app_challenge != 1){
    $resp["msg"] = "This feature is disabled for this group";
    $fields = [
        'gid'=>$gid,
        'challenge'=>$last5,
        'msg'=>"Challenge feature disabled for group",
        'success'=>0,
        'ip'=>$ip,
        'ts'=>date("Y-m-d H:i:s"),
    ];
    $db->insert('omt_app_challenge_logs',$fields);
    echo json_encode($resp);
    die();
}

if($g->local_ip == "" && $g->remote_ip == ""){
    $resp["msg"] = "No IP addresses set for this group";
    $fields = [
        'gid'=>$gid,
        'challenge'=>$last5,
        'msg'=>"No IP addresses set for this group",
        'success'=>0,
        'ip'=>$ip,
        'ts'=>date("Y-m-d H:i:s"),
    ];
    $db->insert('omt_app_challenge_logs',$fields);
    echo json_encode($resp);
    die();
}

$searchQ = $db->query("SELECT 
    m.*,
    u.fname,
    u.lname
FROM 
    omt_user_group_map m 
    LEFT OUTER JOIN users u ON m.userId = u.id
WHERE 
    m.groupId = ? AND m.challenge = ?",[$gid, $last5]);
$searchC = $searchQ->count();

if($searchC < 1){
    $resp["msg"] = "Challenge not found";
    $fields = [
        'gid'=>$gid,
        'challenge'=>$last5,
        'msg'=>"Challenge not found",
        'success'=>0,
        'ip'=>$ip,
        'ts'=>date("Y-m-d H:i:s"),
    ];
    $db->insert('omt_app_challenge_logs',$fields);

    echo json_encode($resp);
    die();
}
$u = $searchQ->first();
$fields = [
    'used'=>1,
    'used_on'=>date("Y-m-d H:i:s"),
    'used_ip'=>ipCheck(),
];
$db->update('omt_user_group_map',$u->id,$fields);
$fields = [
    'gid'=>$gid,
    'uid'=>$u->userId,
    'challenge_batch'=>$u->challenge_batch,
    'challenge'=>$u->challenge,
    'response'=>$u->response,
    'msg'=>"Authenticated",
    'success'=>1,
    'ip'=>$ip,
    'ts'=>date("Y-m-d H:i:s"),
];
$db->insert('omt_app_challenge_logs',$fields);
$resp = ["success"=>true, "msg"=>"Authenticated", "uid"=>$u->userId, "fname"=>$u->fname, "lname"=>$u->lname, "response_code"=>$u->response, 'local_ip'=>$g->local_ip, 'remote_ip'=>$g->remote_ip,"group"=>$gid,    'groupName'=>$g->groupName];
echo json_encode($resp);
die();

// lidump($gid);
// lidump($group);
// lidump($last5);
