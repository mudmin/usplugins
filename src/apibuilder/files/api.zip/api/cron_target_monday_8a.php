<?php
require_once "../users/init.php";
require_once $abs_us_root.$us_url_root."admin/functions/takeout.php";

$code = Input::get('code');

if($code != "VocKbKd7B0b7e"){
  die("np");
}

//This cron now runs on weekdays at 8am

$ip = ipCheck();
require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if(!hasPerm(2) && !in_array($ip, $valid_sync_ips)){
  die("np");
}

if($server_tag == "portal"){



  $startDate = date('Y-m-d'); // Today
  $endDate = date('Y-m-d', strtotime('+7 days'));
  
  $upcomingMeetings = $db->query("SELECT
      m.id,
      m._cid,
      m._gid,
      m._meetingName,
      m._meetingDescription,
      m._meetingDate,
      m._meetingTime,
      m._meetingTZ,
      m._publicCommentOpen,
      m._allowPublicComment,
      m.official_instance,
      c.custName,
      c.custCode,
      c.city,
      c.state,
      c.tz,
      g.id as gid,
      g.groupName,
      g._allowPublicComment as group_allow_comment
  FROM omt_meetings m
  INNER JOIN omt_groups g ON m._gid = g.id
  INNER JOIN omt_customers c ON g.customerId = c.id
  WHERE 1=1
      AND c.active = 1
      AND g.active = 1
      AND m._archived = 0
      AND m._template = 0
      AND m._deleted = 0
      AND c.no_stats = 0
      AND m._meetingDate >= '$startDate'
      AND m._meetingDate <= '$endDate'
  ORDER BY
      m._meetingDate ASC,
      m._meetingTime ASC")->results();

  // Query for meeting feedback from the last 24 hours
  $feedbackResults = $db->query("SELECT
      mi.id,
      mi.mm_uid,
      mi.cid,
      mi.gid,
      mi.dt,
      mi.feedback_rating,
      mi.feedback_comments,
      u.fname,
      u.lname,
      u.email,
      c.custName,
      g.groupName
  FROM omt_meeting_minute_instance mi
  LEFT JOIN users u ON mi.mm_uid = u.id
  LEFT JOIN omt_customers c ON mi.cid = c.id
  LEFT JOIN omt_groups g ON mi.gid = g.id
  WHERE mi.feedback_rating > 0
      AND mi.dt >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
  ORDER BY mi.dt DESC")->results();
  
  // Generate email subject
  $todayDate = date('n/j/Y');
  $endDateFormatted = date('n/j/Y', strtotime('+8 days'));
  $subject = "Upcoming Meetings: $todayDate through $endDateFormatted";

  // Add feedback note to subject if there is feedback
  if (!empty($feedbackResults)) {
    $subject .= " (Customer feedback included)";
  }
  
  // Start building the email body
  $emailBody = '
  <!DOCTYPE html>
  <html>
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>'.$subject.'</title>
      <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { width: 100%; max-width: 800px; margin: 0 auto; }
          h1 { color: #2c5282; text-align: center; margin-bottom: 20px; }
          .intro { margin-bottom: 20px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          th { background-color: #f0f4f8; color: #2c5282; text-align: left; padding: 10px; }
          td { padding: 10px; border-bottom: 1px solid #ddd; }
          tr:nth-child(even) { background-color: #f9fafb; }
          .meeting-date { font-weight: bold; }
          .footer { font-size: 12px; color: #777; text-align: center; margin-top: 30px; }
          .btn { display: inline-block; padding: 8px 15px; background-color: #3182ce; color: white; text-decoration: none; border-radius: 4px; }
      </style>
  </head>
  <body>
      <div class="container">
          <h1>Upcoming Meetings Report</h1>
          
          <div class="intro">
              <p>Below is a list of all upcoming meetings scheduled from '.$todayDate.' through '.$endDateFormatted.'.</p>
          </div>';
  
  // If no meetings found
  if (empty($upcomingMeetings)) {
      $emailBody .= '
          <div>
              <p>No upcoming meetings found for this date range.</p>
          </div>';
  } else {
      // Build the meetings table
      $emailBody .= '
          <table>
              <thead>
                  <tr>
                      <th>Date</th>
                      <th>Time</th>
                      <th>Customer</th>
                      <th>Group</th>
                      <th>Meeting Name</th>
                      <th>Location</th>
                
                  </tr>
              </thead>
              <tbody>';
      
      // Current date for grouping meetings by day
      $currentDate = '';
      
      foreach ($upcomingMeetings as $m) {
          $meetingDate = date('l, F j', strtotime($m->_meetingDate));
          $meetingTime = date('g:i A', strtotime($m->_meetingTime));
          $location = $m->city . ', ' . $m->state;
          $tz = str_replace('America/', '', $m->tz ?? "Unknown");
          
          // Format links for actions
          $printLink = $us_url_root . "customers/meeting/pdf?meeting=" . $m->id . "&type=1&preview=true";
  
          
          $emailBody .= '
                  <tr>
                      <td class="meeting-date">' . $meetingDate . '</td>
                      <td>' . $meetingTime . ' ' . $tz . '</td>
                      <td>' . hed($m->custName) . '</td>
                      <td>' . hed($m->groupName) . '</td>
                      <td>' . hed($m->_meetingName) . '</td>
                      <td>' . hed($location) . '</td>
                     
                  </tr>';
      }
      
      $emailBody .= '
              </tbody>
          </table>';
  }

  // Add Meeting Feedback Section (only if there is feedback)
  if (!empty($feedbackResults)) {
      $emailBody .= '
          <h2 style="color: #2c5282; margin-top: 30px;">Meeting Feedback (Last 24 Hours)</h2>';

      $emailBody .= '
          <table>
              <thead>
                  <tr>
                      <th>Date/Time (UTC)</th>
                      <th>User</th>
                      <th>Customer</th>
                      <th>Group</th>
                      <th>Rating</th>
                      <th>Comments</th>
                  </tr>
              </thead>
              <tbody>';

      foreach ($feedbackResults as $f) {
          $feedbackDate = date('n/j/Y g:i A', strtotime($f->dt));
          $userName = hed($f->fname . ' ' . $f->lname);
          $userEmail = hed($f->email ?? 'N/A');
          $custName = hed($f->custName ?? 'N/A');
          $groupName = hed($f->groupName ?? 'N/A');
          $rating = $f->feedback_rating;
          $comments = !empty($f->feedback_comments) ? hed($f->feedback_comments) : '<em>No comments</em>';

          // Rating display: 1 = thumbs down, 5 = thumbs up
          if ($rating == 1) {
              $ratingDisplay = '👎 Thumbs Down';
          } else if ($rating == 5) {
              $ratingDisplay = '👍 Thumbs Up';
          } else {
              $ratingDisplay = $rating; // fallback for any other values
          }

          $emailBody .= '
                  <tr>
                      <td>' . $feedbackDate . '</td>
                      <td>' . $userName . '<br><small style="color: #777;">' . $userEmail . '</small></td>
                      <td>' . $custName . '</td>
                      <td>' . $groupName . '</td>
                      <td>' . $ratingDisplay . '</td>
                      <td>' . $comments . '</td>
                  </tr>';
      }

      $emailBody .= '
              </tbody>
          </table>';
  }

  // Add footer
  $emailBody .= '
          <div class="footer">
              <p>Report generated: ' . date('m/d/Y g:i A') . '</p>
              <p>This is an automated report. Please do not reply to this email.</p>
          </div>
      </div>
  </body>
  </html>';
  
  $to = [
    "mudmin@gmail.com",
    "jill.lodewegen@openmeetingtech.com", "chad.trice@openmeetingtech.com", "victor.kluck@openmeetingtech.com",
  ];

  // Add Jeff if there is feedback
  if (!empty($feedbackResults)) {
    $to[] = "jeff@redzonestudios.com";
  }

  foreach ($to as $t) {
    email($t, $subject, $emailBody);
  }


  }

