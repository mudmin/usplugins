<?php
define('USERSPICE_DO_NOT_LOG', true);
require_once "../users/init.php";
$code = Input::get('code');
// logger(1,"Cron target minute", "code: $code");
if($code != "VocKbKd7B0b7e"){
  die("np");
}
$ip = ipCheck();
$whatServer = whatServerIsThis();

$timeoutThreshold = date("Y-m-d H:i:s", strtotime("-20 minutes"));
$failed = $db->query("SELECT * FROM omt_meeting_minute_instance
WHERE ready_to_process = 1
AND processed = 0
AND dt < ?", [$timeoutThreshold])->results();
foreach($failed as $f){
  $db->query("UPDATE omt_meeting_minute_instance SET processed = 1, archived = 1 WHERE id = ? ",[$f->id]);
  $data = ["error"=>"Minute processing failed", "details"=>"Instance_id $f->id, group_id $f->gid meeting id $f->_mid"];
  $fields = [
    'user_id'=>1,
    'apicall'=>'bugReport',
    'success'=>1,
    'incoming'=>json_encode($data),
    'ts'=>date("Y-m-d H:i:s"),
    'debug'=>'Cron Target Five'
  ];
  $db->insert('logs_api',$fields);
  dump($db->errorString());
}

sendSecurityReportsToDiscord();

