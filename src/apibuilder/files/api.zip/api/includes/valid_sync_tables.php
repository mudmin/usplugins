<?php
$tables = [
  'omt_lang', 'omt_lang_sections', 'omt_lang_strings', 'omt_lang_strings_trans', 'omt_tooltips', 'omt_tooltips_categories','plg_download_files','plg_download_links','plg_badges', 'plg_badges_cats','plg_badge_settings', 'omt_cold_packages', 'omt_licensetypes', 'plg_links',
  'omt_oauth_providers', 'omt_msg_templates', 'omt_msg_template_parts', 
  'omt_streams_vimeo','omt_video_proxy',
];

$valid_sync_ips = getValidSyncIps();
$valid_sync_ips_other = [
  '100.115.240.95', //cms tailscale
  '107.174.133.228', //cms public
  '97.100.24.216',
  '50.83.74.230',
  '67.227.190.124',
  '::1',
  '192.227.164.132', //security.omt-appserver
  '23.95.92.107', //knox
  '74.48.79.209', //document server pdf1.omt-appserver.com
  '198.46.211.158', //document server pdf2.omt-appserver.com
  '195.179.202.110', //document server pdf.userspice.com
  '194.233.103.103', //document server pdf2.userspice.com
  '216.144.229.107', //document server pdf3.omt-appserver.com

  '107.173.91.207', //document server pdf4
  '192.227.252.88', //document server pdf5


];
foreach($valid_sync_ips_other as $sync_ip){
  if(!in_array($sync_ip,$valid_sync_ips)){
    $valid_sync_ips[] = $sync_ip;
  }
}

// $valid_doc_servers = [
//   'http://192.168.95.101/html/',
//   'https://pdf.userspice.com/',
//   'https://pdf2.userspice.com/',
//   // 'https://omt-docserver.com/',
//   'https://pdf1.omt-appserver.com/',
//   'https://pdf2.omt-appserver.com/',
// 'https://pdf3.omt-appserver.com/',
// ];

$ai_servers = [
  '1'=>'http://100.109.219.50/',
];

function getValidSyncIps() {
    global $db;
    
    $valid_sync_ips = [];
    
    // Query to get all distinct IPs from both tables
    $query = "
        SELECT DISTINCT ip AS ip_address FROM omt_servers WHERE ip IS NOT NULL AND ip != ''
        UNION
        SELECT DISTINCT tailscale_ip AS ip_address FROM omt_servers WHERE tailscale_ip IS NOT NULL AND tailscale_ip != ''
        UNION
        SELECT DISTINCT ip AS ip_address FROM omt_servers_internal WHERE ip IS NOT NULL AND ip != ''
        UNION
        SELECT DISTINCT tailscale_ip AS ip_address FROM omt_servers_internal WHERE tailscale_ip IS NOT NULL AND tailscale_ip != ''
    ";
    
    $results = $db->query($query)->results();
    
    foreach($results as $row) {
        $valid_sync_ips[] = $row->ip_address;
    }
    
    return $valid_sync_ips;
}