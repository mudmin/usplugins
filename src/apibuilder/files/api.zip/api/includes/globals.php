<?php
if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted
global $db,$version,$data,$response,$auth,$sendDevMessage,$settings,$lang,$language,$ip,$apiSettings;
