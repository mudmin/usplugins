<?php
require_once "../users/init.php";
$code = Input::get('code');

if($code != "VocKbKd7B0b7e"){
  die("np");
}


$ip = ipCheck();
require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if(!hasPerm(2) && !in_array($ip, $valid_sync_ips)){
  die("np");
}


if($server_tag == "portal"){
if(isset($user) && $user->isLoggedIn()){
  $attempt =fetchZohoCRM(false,"Accounts");
  lidump($attempt);
}else{
  fetchZohoCRM(false,"Accounts");
}
}

logger(1,"Daily AQ Cron","Accepted");

$aq = $db->query("SELECT * FROM omt_groups WHERE aqid > 0")->results();
foreach($aq as $a){
  fetchAQMeetings($a->id, false);
}
