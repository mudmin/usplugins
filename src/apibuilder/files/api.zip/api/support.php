<?php 
require_once("../users/init.php");
$vars = [];
foreach($_GET as $k=>$v){
    $vars[Input::sanitize($k)] = Input::sanitize($v);
}
logger(0,'support link', '-->',json_encode($vars));
Redirect::to($settings->support_link);