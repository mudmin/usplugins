<?php
require_once "../users/init.php";
require_once $abs_us_root.$us_url_root."admin/functions/takeout.php";
if(isset($cold_storage_db)){
$code = Input::get('code');

if($code != "VocKbKd7B0b7e"){
  die("np");
}


$ip = ipCheck();
require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if(!hasPerm(2) && !in_array($ip, $valid_sync_ips)){
  die("np");
}

$last = $db->query("SELECT * FROM omt_word_asset_blocks WHERE gid > 0 ORDER BY id DESC LIMIT 1")->first();
$theLastId = $last->id;
$db->query("DELETE FROM omt_word_asset_blocks WHERE gid = 0 AND id <= ?", [$theLastId]);
// takeoutImages();
// $db->query("UPDATE users
// SET cloak_allowed = 0
// WHERE id NOT IN (
//     SELECT DISTINCT user_id
//     FROM user_permission_matches
//     WHERE permission_id IN (2, 8, 9)
// )");
// //define generic backup tables here
// $tables = [
//   "omt_configs_rooms",
//   "omt_meetings_templates",
//   "omt_templates_customer",
//   "omt_meeting_minute_configs",
//   "omt_agenda_configs",
// ];

// //backup meetings
// $backup = $db->query("SELECT * FROM omt_meetings")->results();
// foreach($backup as $b){
//     $attempt = meetingTakeout($b->id, "", 90);
// }


// //backup configs
// $backup = $db->query("SELECT * FROM omt_configs")->results();
// foreach($backup as $b){
//     $attempt = configTakeout($b->id, "", 90);
// }

// //backup word docs
// $backup = $db->query("SELECT * FROM omt_word_assets")->results();
// foreach($backup as $b){
//     $attempt = wordTakeout($b->id, "", 90);
// }

// $backup = $db->query("SELECT * FROM omt_configs_rooms")->results();
// foreach($backup as $b){
//     $attempt = genericTakeout("omt_configs_rooms", $b->id, "", 90);
// }



// foreach($tables as $table){
//   $backup = $db->query("SELECT * FROM $table")->results();
//   foreach($backup as $b){
//       $attempt = genericTakeout($table, $b->id, "", 90);
//   }
// }

// }else{
//   echo "Cold storage not configured";
// }

}
