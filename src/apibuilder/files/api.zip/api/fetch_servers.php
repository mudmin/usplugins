<?php
if(!isset($_GET['request']) || $_GET['request'] != "IKarTD3QuMBfSNGONKtT"){
    die("");
}

$noMaintenanceRedirect = true;
require_once "../users/init.php";

$servers = $db->query("SELECT serverName, `url`, `ip`, `production`, `localhost` FROM omt_servers WHERE active = 1")->results();  

$resp = ["success"=>true, "servers"=>$servers];
echo json_encode($resp);
die();
