<?php
require_once '../users/init.php';

//this file is called in the daily cron but can also be called directly  
$ip = ipCheck();
require_once $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if (!hasPerm(2) && !in_array($ip, $valid_sync_ips)) {
  email("mudmin@gmail.com", "Cron fetch content $actual_site_url", "FAILED. Invalid IP - " . $ip);
  die("np");
}
require_once $abs_us_root . $us_url_root . "admin/functions/omt_network.php";
logger(1, "cms content fetch", "hit");
if (isset($server_tag)) {
  $content = fetchRemoteOMTCMS($server_tag, "https://cms.omt-appserver.com/usersc/plugins/simple_cms/api/", "FEBPM-CWHWZ-5V65B-79189-92224", true);
  $content = json_decode($content, true);
  if (isset($content['data'])) {
    $data = base64_decode($content['data']);
    $data = json_decode($data, true);
    foreach ($data as $d) {
      //turn comma separated tags into array
      $d['tags'] = explode(",", $d['tags']);
      $dynamicFile = $abs_us_root . $us_url_root . "cache/dynamic_header_footer.php";
      if (!file_exists($dynamicFile)) {
        $dynamicFile = $abs_us_root . $us_url_root . "cache/dynamic_header_footer.php";
      }
      //empty dynamic file
      file_put_contents($dynamicFile, "");
      $dynamicContent = [];
      foreach ($d['tags'] as $t) {
        // 
          if(isset($actual_site_url)){
              $d['content'] = str_replace("{{actual_site_url}}", $actual_site_url, $d['content']);
              $d['content'] = str_replace("%257B%257Bactual_site_url%257D%257D", $actual_site_url, $d['content']);
            }
        if (trim($t) == "-homepage") {
          writeCMSContentToCache($d['content'], "homepage.php");
        }
        if (trim($t) == "-forgot-1") {
          writeCMSContentToCache($d['content'], "forgot_pw_1.php");
        }
        if (trim($t) == "-forgot-2") {
          writeCMSContentToCache($d['content'], "forgot_pw_sent.php"); //pw link has been sent
        }
        if (trim($t) == "-forgot-3") {
          writeCMSContentToCache($d['content'], "forgot_pw_reset.php"); //actual change password form
        }
        if (trim($t) == "-forgot-4") {
          writeCMSContentToCache($d['content'], "forgot_pw_success.php"); //success message for pw change
        }
        if (trim($t) == "-forgot-5") {
          writeCMSContentToCache($d['content'], "forgot_pw_error.php"); //success message for pw change
        }
        if (trim($t) == "-public-download") {
          writeCMSContentToCache($d['content'], "download.php"); //public download buttons
        }
        if (trim($t) == "-configDefs") {
          writeCMSContentToCache($d['content'], "configDefs.php"); //config page config type definitions
        }
        
        if (trim($t) == "-cms-header-footer") {
          $dynamicContent[$d['id']] = $d['content'];
          
          // Create individual file for each -cms-header-footer item
          $individualFile = $abs_us_root . $us_url_root . "cache/dynamic_{$d['id']}.php";
          file_put_contents($individualFile, "<?php\n");
          file_put_contents($individualFile, "\$dynamic_{$d['id']} = '" . addslashes($d['content']) . "';\n", FILE_APPEND);
          file_put_contents($individualFile, "?>\n", FILE_APPEND);
        }
        
        $batch = [
          "login-header", "login-header-app", "login-footer", "login-footer-app", "zoho-login-header", "zoho-login-footer", "meeting-manager-login",
        ];
        foreach ($batch as $b) {
          if (trim($t) == "-" . $b) {
            if(isset($actual_site_url)){
              $d['content'] = str_replace("{{actual_site_url}}", $actual_site_url, $d['content']);
            }
            writeCMSContentToCache($d['content'], $b . ".php", true); // kill blank content and replace with ""
          }
        }
      }
   
      // Write dynamic content to file with $id as a variable
      file_put_contents($dynamicFile, "<?php\n");
      foreach ($dynamicContent as $k => $v) {
        file_put_contents($dynamicFile, "\$dynamic_{$k} = '" . addslashes($v) . "';\n", FILE_APPEND);
      }
      file_put_contents($dynamicFile, "?>\n", FILE_APPEND);
    }
  }
}
?>