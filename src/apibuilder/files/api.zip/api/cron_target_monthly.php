<?php
require_once "../users/init.php";
require_once $abs_us_root.$us_url_root."admin/functions/takeout.php";

$code = Input::get('code');

if($code != "VocKbKd7B0b7e"){
  die("np");
}


$ip = ipCheck();
require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if(!hasPerm(2) && !in_array($ip, $valid_sync_ips)){
  die("np");
}


if($server_tag == "portal" || $server_tag == "dev"){
  //email report on expiring license
  $message = "
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>License and Trial Expiration Report</title>
</head>
<body style='font-family: Arial, sans-serif;'>";

// --- Section 1: Licenses Expiring Soon ---
$today = date("Y-m-d");
$threeMonthsFromNow = date("Y-m-d", strtotime("+3 months"));
$q_license_expiring = $db->query("SELECT id, custName, licenseExpirationDate
                                  FROM omt_customers
                                  WHERE active = 1 AND licenseExpirationDate BETWEEN ? AND ?", [$today, $threeMonthsFromNow]);
$c_license_expiring = $q_license_expiring->count();
if ($c_license_expiring > 0) {
    $none_license_expiring = "";
    $r_license_expiring = $q_license_expiring->results();
} else {
    $none_license_expiring = ": <span style='color: #28a745;'>None</span><br>";
}
$message .= "<h2>Licenses Expiring in the next 3 months {$none_license_expiring}</h2>";

if ($c_license_expiring > 0) {
    $message .= "
    <table style='width: 100%; border-collapse: collapse;'>
        <tbody>";
    $i = 0; // Initialize counter for this table
    foreach ($r_license_expiring as $r) {
        $message .= "
            <tr style='background-color: " . ($i % 2 == 0 ? '#f2f2f2' : '#ffffff') . ";'>
                <td style='padding: 8px; width: 75%;'>
                    <a href='{$actual_site_url}/support/cust_license_info?c={$r->id}'>
                        {$r->custName}
                    </a>
                </td>
                <td style='padding: 8px; width: 25%;'>
                    {$r->licenseExpirationDate}
                </td>
            </tr>";
        $i++;
    }
    $message .= "
        </tbody>
    </table>";
}

// --- Section 2: Active Expired Licenses ---
$today = date("Y-m-d");
$q_license_expired = $db->query("SELECT id, custName, licenseExpirationDate
                                FROM omt_customers
                                WHERE active = 1 AND licenseExpirationDate <= ?", [$today]);
$c_license_expired = $q_license_expired->count();
if ($c_license_expired > 0) {
    $none_license_expired = "";
    $r_license_expired = $q_license_expired->results();
} else {
    $none_license_expired = ": <span style='color: #28a745;'>None</span><br>";
}

$message .= "<h2>Active Expired Licenses {$none_license_expired}</h2>";

if ($c_license_expired > 0) {
    $message .= "
    <table style='width: 100%; border-collapse: collapse;'>
        <tbody>";
    $i = 0; // Reset counter for this table
    foreach ($r_license_expired as $r) {
        $message .= "
            <tr style='background-color: " . ($i % 2 == 0 ? '#f2f2f2' : '#ffffff') . ";'>
                <td style='padding: 8px; width: 75%;'>
                    <a href='{$actual_site_url}/support/cust_license_info?c={$r->id}'>
                        {$r->custName}
                    </a>
                </td>
                <td style='padding: 8px; width: 25%;'>
                    {$r->licenseExpirationDate}
                </td>
            </tr>";
        $i++;
    }
    $message .= "
        </tbody>
    </table>";
}

// --- NEW Section 3: Free Trials Expiring Soon ---
$today = date("Y-m-d");
$threeMonthsFromNow = date("Y-m-d", strtotime("+3 months"));
$q_trial_expiring = $db->query("SELECT id, custName, trial_end_date
                                FROM omt_customers
                                WHERE active = 1
                                AND free_trial = 1
                                AND trial_end_date BETWEEN ? AND ?", [$today, $threeMonthsFromNow]);
$c_trial_expiring = $q_trial_expiring->count();
if ($c_trial_expiring > 0) {
    $none_trial_expiring = "";
    $r_trial_expiring = $q_trial_expiring->results();
} else {
    $none_trial_expiring = ": <span style='color: #28a745;'>None</span><br>";
}
$message .= "<h2>Free Feature Trials Expiring in the next 3 months {$none_trial_expiring}</h2>";

if ($c_trial_expiring > 0) {
    $message .= "
    <table style='width: 100%; border-collapse: collapse;'>
        <tbody>";
    $i = 0; // Reset counter for this table
    foreach ($r_trial_expiring as $r) {
        // Format the date/datetime - assuming trial_end_date is DATETIME
        // You might want to format it differently (e.g., only show date)
        $trialEndDateFormatted = (new DateTime($r->trial_end_date))->format('Y-m-d'); // Example: Only show date part

        $message .= "
            <tr style='background-color: " . ($i % 2 == 0 ? '#f2f2f2' : '#ffffff') . ";'>
                <td style='padding: 8px; width: 75%;'>
                    <a href='{$actual_site_url}/support/cust_license_info?c={$r->id}'>
                        {$r->custName}
                    </a>
                </td>
                <td style='padding: 8px; width: 25%;'>
                    {$trialEndDateFormatted}
                </td>
            </tr>";
        $i++;
    }
    $message .= "
        </tbody>
    </table>";
}


// --- NEW Section 4: Active Expired Free Trials ---
$today = date("Y-m-d");
$q_trial_expired = $db->query("SELECT id, custName, trial_end_date
                               FROM omt_customers
                               WHERE active = 1
                               AND free_trial = 1
                               AND trial_end_date <= ?", [$today]);
$c_trial_expired = $q_trial_expired->count();
if ($c_trial_expired > 0) {
    $none_trial_expired = "";
    $r_trial_expired = $q_trial_expired->results();
} else {
    $none_trial_expired = ": <span style='color: #28a745;'>None</span><br>";
}

$message .= "<h2>Active Expired Free Trials {$none_trial_expired}</h2>";

if ($c_trial_expired > 0) {
    $message .= "
    <table style='width: 100%; border-collapse: collapse;'>
        <tbody>";
    $i = 0; // Reset counter for this table
    foreach ($r_trial_expired as $r) {
         // Format the date/datetime - assuming trial_end_date is DATETIME
        $trialEndDateFormatted = (new DateTime($r->trial_end_date))->format('Y-m-d'); // Example: Only show date part

        $message .= "
            <tr style='background-color: " . ($i % 2 == 0 ? '#f2f2f2' : '#ffffff') . ";'>
                <td style='padding: 8px; width: 75%;'>
                    <a href='{$actual_site_url}/support/cust_license_info?c={$r->id}'>
                        {$r->custName}
                    </a>
                </td>
                <td style='padding: 8px; width: 25%;'>
                    {$trialEndDateFormatted}
                </td>
            </tr>";
        $i++;
    }
    $message .= "
        </tbody>
    </table>";
}


// --- Final closing tags and email sending ---
$message .= "
</body>
</html>";

$to = [
    "mudmin@gmail.com",
    "jill.lodewegen@openmeetingtech.com", "chad.trice@openmeetingtech.com", "carly.hiltner@openmeetingtech.com", "ellie.wohnoutka@openmeetingtech.com"
];
$subject = "OMT License & Trial Expiration Report for " . ucFirst($server_tag) . " Server " . date("Y-m-d");

foreach ($to as $t) {
    email($t, $subject, $message);
}
}

