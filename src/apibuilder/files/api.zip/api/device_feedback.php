<?php
$noMaintenanceRedirect = true;
require_once "../users/init.php";
$resp = ["success"=>true, "msg"=>"", "id"=>0];
//this form allows users to probide device feedback for apps.They will submit their device string and we will look it up in omt_devices to make sure it's valid and store the feedback in 


$device = Input::get('device');
$cid = Input::get('cid');
$check = $db->query("SELECT * FROM omt_devices WHERE  device_string = ?", [$device]);
if(!$check->count()){
    $resp['success'] = false;
    $resp['msg'] = "Device not recognized.";
    echo json_encode($resp);
    exit();
}
$deviceData = $check->first();
$software_type = Input::get('software_type'); //ma or dm
$software_version = Input::get('software_version');
$rating = Input::get('rating');
$comments = Input::get('comments');
$uid = Input::get('uid');
$gid = Input::get('group');
$instance = Input::get('instance');
$mid = Input::get('mid');
// get all the device information from the request to make sure it is the latest information and store it with the feedback
$device_type = Input::get('device_type');
$device_os = Input::get('device_os');
$device_specs = Input::get('device_specs');

$fields = [
    'uid' => $uid,
    'gid' => $gid,
    'instance' => $instance,
    'mid' => $mid,
    'sw_type' => $software_type,
    'sw_version' => $software_version,
    'device_type' => $device_type,
    'device_os' => $device_os,
    'device_specs' => $device_specs,
    'feedback_rating' => $rating,
    'feedback_comments' => $comments
];
$db->insert('omt_devices_feedback', $fields);
$resp['id'] = $db->lastId();
$resp['msg'] = "Thank you for your feedback!";
echo json_encode($resp);
exit();



