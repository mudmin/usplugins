<?php
require_once "../users/init.php";
require_once $abs_us_root.$us_url_root."admin/functions/takeout.php";
if(isset($cold_storage_db)){
$code = Input::get('code');

if($code != "VocKbKd7B0b7e"){
  die("np");
}


$ip = ipCheck();
require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if(!hasPerm(2) && !in_array($ip, $valid_sync_ips)){
  die("np");
}

$date = date("Y-m-d");
$db2 = DB::getDB($cold_storage_db);
$db2->query("DELETE FROM omt_cold_backup WHERE expires < ?",[$date]);
}