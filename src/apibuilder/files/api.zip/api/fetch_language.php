<?php
die("this api has been moved to cms");
$noMaintenanceRedirect = true;
require_once "../users/init.php";
logger(1,"API","fetch_language.php called");
if(whatServerIsThis() != "dev"){
  die("This api should only be called on dev.");
}
$ip = ipCheck();
require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if(!hasPerm(2) && !in_array($ip, $valid_sync_ips)){
  email("mudmin@gmail.com","Cron fetch language $actual_site_url","FAILED. Invalid IP - ".$ip);
  die("np");
}


$data = [];
foreach($tables as $t){
  $data[$t] = $db->query("SELECT * FROM $t")->results();
}
echo json_encode($data);die;
