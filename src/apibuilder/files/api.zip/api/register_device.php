<?php
$noMaintenanceRedirect = true;
require_once "../users/init.php";
$resp = ["success"=>true, "msg"=>"", "id"=>0];
$device = Input::get('device');
$ma_server = Input::get('ma_server');
$dm_server = Input::get('dm_server');

$ma_version = Input::get('ma_version');
$dm_version = Input::get('dm_version');

$cols = ["ma_version", "dm_version", "ma_server", "dm_server"];
$vars = $_GET;
$vars = Input::sanitize($vars);
$vars = json_encode($vars);

logger(1, "Registering device:", $vars);
if($device == ""){
    $resp["success"] = false;
    $resp["msg"] = "Device string not provided";
    //logger(1, "Registering device failed:", json_encode($resp));
    echo json_encode($resp);
    die();
}
$checkQ = $db->query("SELECT id FROM omt_devices WHERE device_string = ?", [$device]);
$checkC = $db->count();
if($checkC > 0){

        $check = $checkQ->first();
        $fields = [];
        foreach($cols as $col){
            if(Input::get($col) != ""){
                $fields[$col] = Input::get($col);
            }
        }
        $db->update("omt_devices", $check->id, $fields);
        $resp["msg"] = "Device updated";
        //logger(1, "Registering device updated:", json_encode($resp));
        //logger(1, "Registering device updated:", $db->errorString());   

    
}else{
    $fields = ["device_string"=>$device, "created_on"=>date("Y-m-d H:i:s")];
    foreach($cols as $col){
        if(Input::get($col) != ""){
            $fields[$col] = Input::get($col);
        }
    }
    $db->insert("omt_devices",$fields);
    $resp["msg"] = "Device registered successfully.";
    $resp["id"] = $db->lastId();
    //logger(1, "Registering device success:", json_encode($resp));
    //logger(1, "Registering device success:", $db->errorString());
}

echo json_encode($resp);
