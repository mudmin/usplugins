<?php
/**
 * delete_proxy.php  –  API endpoint for proxy deletion/revocation
 * -------------------------------------------------------
 * Marks a proxy as revoked based on device_id and cloud_server_id
 * Only allowed from IPs or Tailscale IPs listed in omt_servers_internal
 */

require_once '../users/init.php';
header('Content-Type: application/json');

logger(0, "proxy_delete", "Delete proxy API endpoint called", ["remote_addr" => Server::get('REMOTE_ADDR'), "request_method" => Server::get('REQUEST_METHOD')]);

// ---------------------------------------------------------------
// Enforce POST + JSON
// ---------------------------------------------------------------
if (Server::get('REQUEST_METHOD') !== 'POST') {
    logger(0, "proxy_delete", "Request rejected: non-POST method", ["method" => Server::get('REQUEST_METHOD')]);
    http_response_code(405);
    echo json_encode(['error' => 'POST only']);
    exit;
}

$raw  = file_get_contents('php://input');
logger(0, "proxy_delete", "Raw input received", ["raw_length" => strlen($raw)]);

$data = json_decode($raw, true);
if (!is_array($data)) {
    logger(0, "proxy_delete", "Request rejected: invalid JSON", ["raw_input" => substr($raw, 0, 200)]);
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}
logger(0, "proxy_delete", "JSON decoded successfully", ["data_keys" => array_keys($data)]);

// ---------------------------------------------------------------
// Extract required fields
// ---------------------------------------------------------------
$deviceId      = $data['device_id']      ?? '';
$cloudServerId = isset($data['cloud_server_id']) ? (int)$data['cloud_server_id'] : null;

logger(0, "proxy_delete", "Fields extracted", [
    "device_id" => $deviceId,
    "cloud_server_id" => $cloudServerId
]);

// Validate required fields
if (
    !preg_match('/^[0-9A-Za-z\-]{3,64}$/', $deviceId) ||
    $cloudServerId === null ||
    $cloudServerId <= 0
) {
    logger(0, "proxy_delete", "Request rejected: malformed or missing required fields", [
        "device_id_valid" => preg_match('/^[0-9A-Za-z\-]{3,64}$/', $deviceId) ? true : false,
        "cloud_server_id" => $cloudServerId
    ]);
    http_response_code(400);
    echo json_encode(['error' => 'Invalid or missing device_id or cloud_server_id']);
    exit;
}
logger(0, "proxy_delete", "Field validation passed");

// ---------------------------------------------------------------
// IP Authorization Check
// ---------------------------------------------------------------
$clientIp = Server::get('REMOTE_ADDR');
logger(0, "proxy_delete", "Client IP extracted", ["client_ip" => $clientIp]);

// Confirm IP or tailscale_ip belongs to an active proxy server
$q = $db->query(
    "SELECT * FROM omt_servers_internal
     WHERE active = 1 AND video_proxy = 1
       AND (ip = ? OR tailscale_ip = ?)",
    [$clientIp, $clientIp]
);
$c = $q->count();
logger(0, "proxy_delete", "Queried omt_servers_internal for IP authorization", ["query_count" => $c, "client_ip" => $clientIp]);

if ($q->count() < 1) {
    logger(0, "proxy_delete", "Request rejected: unauthorized IP", ["client_ip" => $clientIp]);
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized', 'ip' => $clientIp]);
    exit;
}
logger(0, "proxy_delete", "IP authorization passed", ["client_ip" => $clientIp]);

// ---------------------------------------------------------------
// Find and revoke the proxy device
// ---------------------------------------------------------------
$existingQ = $db->query(
    "SELECT id, device_id, cloud_server_id, status FROM omt_video_proxy_devices
     WHERE device_id = ? AND cloud_server_id = ?",
    [$deviceId, $cloudServerId]
);
$existingC = $existingQ->count();

logger(0, "proxy_delete", "Searched for device", [
    "device_id" => $deviceId,
    "cloud_server_id" => $cloudServerId,
    "found_count" => $existingC
]);

if ($existingC < 1) {
    logger(0, "proxy_delete", "Device not found", [
        "device_id" => $deviceId,
        "cloud_server_id" => $cloudServerId
    ]);
    http_response_code(404);
    echo json_encode(['error' => 'Device not found or cloud_server_id mismatch']);
    exit;
}

$device = $existingQ->first();
$previousStatus = $device->status;

logger(0, "proxy_delete", "Deleting device", [
    "device_id" => $deviceId,
    "record_id" => $device->id,
    "previous_status" => $previousStatus
]);

// Delete the device record
$db->delete('omt_video_proxy_devices', $device->id);

if ($db->error()) {
    logger(0, "proxy_delete", "Failed to delete device: database error", ["error" => $db->errorString()]);
    http_response_code(500);
    echo json_encode(['error' => 'Database error during deletion']);
    exit;
}

logger(0, "proxy_delete", "Device deleted successfully", [
    "device_id" => $deviceId,
    "record_id" => $device->id,
    "previous_status" => $previousStatus,
    "client_ip" => $clientIp
]);

echo json_encode([
    'ok'              => true,
    'action'          => 'deleted',
    'device_id'       => $deviceId,
    'cloud_server_id' => $cloudServerId,
    'previous_status' => $previousStatus,
    'ip'              => $clientIp
]);
