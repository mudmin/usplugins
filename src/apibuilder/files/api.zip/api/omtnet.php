<?php
require_once '../users/init.php';
$ip = ipCheck();
require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if(!hasPerm(2) && !in_array($ip, $valid_sync_ips)){
    email("mudmin@gmail.com","omtnet $actual_site_url","FAILED. Invalid IP - ".$ip);
  die("np");
}
logger(1,"omtnet","hit");
require_once $abs_us_root . $us_url_root . "admin/functions/omt_network.php";

$action = Input::get('action');
if($action == "sync_customers"){
    // logger(1,"omtnet","sync_customers");
 
    //this is invalidating the OMTNetData
    // $data = fetchOmtnetData($respond = true);
    // lidump($data);

}else{
    // $data = [
    //     'get'   => $_GET,
    //     'post'  => $_POST,
    // ];
    // logger("1","omtnet",$action, json_encode($data));
}
