<?php 
require_once("../users/init.php");
$ip = ipCheck();
require $abs_us_root . $us_url_root . 'api/includes/valid_sync_tables.php';
if(!in_array($ip, $valid_sync_ips)){
if(!hasPerm(2)){
logger(1,"INVALID Webhook hit", "IP: $ip");
  die("np - hp2");
}
}
// http://localhost/omt/api/webhook?method=doc_progress&id_value=239&code=OKsHMM&success=1&response_msg=done
$method = Input::get('method');
if($method == "doc_progress"){
    $job_id = Input::get('job_id');
    $code = Input::get('code');
    $id_value = Input::get('id_value');
    $success = Input::get('success');
    if($success == ""){ $success = 0; }
   
    $response_msg = Input::get('response_msg');
    $responded_on = date("Y-m-d H:i:s");
    $checkQ = $db->query("SELECT * FROM omt_manifest_responses WHERE id_value = ? AND code = ?",[$id_value, $code]);
    $checkC = $checkQ->count();
    if($checkC == 0){
        dump($id_value);
        dump($code);
        die("np - no record");
    }else{
        $check = $checkQ->first();
        $fields = [
            "responded"=>1,
            "responded_on"=>$responded_on,
            "response_msg"=>$response_msg,
            "success"=>$success,
        ];
        $db->update("omt_manifest_responses", $check->id, $fields);
    }
    die("ok");
}

