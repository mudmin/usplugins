<?php
require_once "../users/init.php";
$resp = ['succes'=>false, 'message'=>'Invalid request'];
$auth_code = Input::get('auth_code');
if($auth_code != $settings->auth_code){
  echo json_encode($resp);die;
}
$uuid = Input::get('uuid');
if($uuid == ''){
    $resp['message'] = 'Invalid data provided. Error 100';
    echo json_encode($resp);die;
}
$fields = [

    'os'=>Input::get('os'),
    'current_user'=>Input::get('user'),
    'current_meeting'=>Input::get('meeting'),
    'current_group'=>Input::get('group'),
    'current_ip'=>ipCheck(),
    'current_version'=>Input::get('version'),
    'last_ping'=>date('Y-m-d H:i:s')
];
$checkQ = $db->query("SELECT * FROM omt_ma_devices WHERE uuid = ?", [$uuid]);
$checkC = $checkQ->count();
if($checkC > 0){
    $check = $checkQ->first();
    $db->update("omt_ma_devices", $check->id, $fields);
    $fields['device_id'] = $check->id;
    $resp['message'] = 'Device updated';
     
}else{
    $fields['uuid'] = $uuid;
    $db->insert("omt_ma_devices", $fields);
    unset($fields['uuid']);
    $fields['device_id'] = $db->lastId();
    $resp['message'] = 'Device registered';
}

$fields['ts'] = $fields['last_ping'];
unset($fields['last_ping']);
$db->insert("omt_ma_device_pings", $fields);  

$resp['succes'] = true;
echo json_encode($resp);die;
