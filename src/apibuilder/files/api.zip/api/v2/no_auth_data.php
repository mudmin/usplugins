<?php
if (count(get_included_files()) == 1) die(); //Direct Access Not Permitted
require_once "includes/globals.php";
$response['devMessage'][] = "Invalid authentication data provided";
apibuilderBan($ip);
