I left these files broken out into different sets of files for account linking, login, and join because you can do other logic during each of these steps as you see fit.
