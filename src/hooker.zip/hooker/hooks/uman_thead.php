<?php if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted Leave this line in place?>
<th><?php echo ucfirst(pointsNameReturn());?></th>
