The Meekro class included has been modified from its original form for compatibility reasons.

The class has been renamed MDB from DB
A find of DB::
was replaced with MDB::
