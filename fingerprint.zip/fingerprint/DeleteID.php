<?php
require_once '../../../users/init.php';
if(!hasPerm([2],$user->data()->id)){die("invalid token");}
$db = DB::getInstance();
require 'web.config.php';
use CloudABISSampleWebApp_CloudABIS\CloudABISConnector;
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
function LoadCloudABISToken()
{
  $cloudABISConnector = new CloudABISConnector(CloudABISAppKey, CloudABISSecretKey, CloudABIS_API_URL, CloudABISCustomerKey, ENGINE_NAME);

  $token = $cloudABISConnector->GetCloudABISToken();
  if ( ! is_null($token) && isset($token->access_token) != "" )
  {
    $_SESSION['access_token'] = $token->access_token;
    //SessionManager.CloudABISAPIToken = token.AccessToken;
    //SessionManager.CloudABISCredentials = cloudABISCredentials;
  }
  else
  {
    die("CloudABIS Not Authorized!. Please check credentails");
  }
}

LoadCloudABISToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Delete ID Form</title>
</head>
<body>
  <?php require 'headermenu.php';?>
  <div class="formWrapper text-center">
    <form class="commonForm" action="" method="POST">
      <h1 class="headline">Delete ID</h1>

      <div><br>
        <label for="deleteID">ID</label>
        <input type="text" name="deleteID" id="deleteID" value="">
      </div>
      <div>
        <input type="submit" name="delete" value="Delete ID" class="btn btn-danger">
      </div>

    </form>
    <label id="serverResult"></label>

    <?php
    if (isset($_POST['delete'])) {
      if ($_POST['delete'] != "") {
        $deleteID = $_POST['deleteID'];

        try
        {
          if ($deleteID != "") {
            if (isset($_SESSION['access_token']) && $_SESSION['access_token'] != "") {
              $cloudABISConnector = new CloudABISConnector(CloudABISAppKey, CloudABISSecretKey, CloudABIS_API_URL, CloudABISCustomerKey, ENGINE_NAME);
              $lblMessageText = $cloudABISConnector->RemoveID($deleteID, $_SESSION['access_token']);
              SetStatus($lblMessageText);
            } else {
              die("missing access token");
            }
          } else {
            SetStatus("Please give an ID");
          }

        } catch (Exception $ex) {
          SetStatus($ex->Message());
        }
      } else {
        SetStatus("Please put registration id");
      }
    }

    function SetStatus($message)
    {
      echo '<h3 class="sresponse"> Server response: '.$message.'</h3>';
    }
    ?>
  </div>
  <script>
  function backToHome() {
    window.location.href = "<?=$us_url_root?>users/admin.php?view=plugins_config&plugin=fingerprint";
  }
</script>
<?php   include 'userslist.php'; ?>
</body>
</html>
