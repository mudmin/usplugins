<?php
require_once '../../../users/init.php';
// if(!hasPerm([2],$user->data()->id)){die("invalid token");}
$db = DB::getInstance();
require 'web.config.php';
use CloudABISSampleWebApp_CloudABIS\CloudABISConnector;
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
function LoadCloudABISToken()
{
  global $us_url_root;
  $cloudABISConnector = new CloudABISConnector(CloudABISAppKey, CloudABISSecretKey, CloudABIS_API_URL, CloudABISCustomerKey, ENGINE_NAME);

  $token = $cloudABISConnector->GetCloudABISToken();
  if ( ! is_null($token) && isset($token->access_token) != "" )
  {
    $_SESSION['access_token'] = $token->access_token;
    // Redirect::to($us_url_root.'users/admin.php?view=plugins_config&plugin=fingerprint&err=Reader+set');
  }
  else
  {
    die("CloudABIS Not Authorized!. Please check credentails");
  }
}

LoadCloudABISToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Active Device</title>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js" type="text/javascript"></script>

  <script type="text/javascript">
  function setConfiguration() {
    var engineName = document.getElementById("engineName");
    engineName = engineName.options[engineName.selectedIndex].value;
    var templateFormat = document.getElementById("templateFormat");
    templateFormat = templateFormat.options[templateFormat.selectedIndex].value;

    var deviceName = document.getElementById("deviceName");
    deviceName = deviceName.options[deviceName.selectedIndex].value;

    if ( engineName != '' ) {
      //set credentials in cookey or any others client storage or get your storage
      setCookie("CSDeviceName", deviceName, 7);
      setCookie("CABEngineName", engineName, 7);
      setCookie("CSTempalteFormat", templateFormat, 7);

      window.location.href = "<?=$us_url_root?>users/admin.php?view=plugins_config&plugin=fingerprint";
    } else {
      failCall("Please put required values.");
    }

  }

  function setCookie(name, value, days) {
    var expires = "";
    if (days) {
      var date = new Date();
      date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
      expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
  }
  function failCall(status) {
    document.getElementById('lblMessage').innerHTML = status;
  }
</script>
</head>
<body>
  <?php require 'headermenu.php';?>
  <div class="formWrapper text-center">
    <div class="iholder">
      <h1 class="headline">Active Device</h1>
      <form class="" action="" method="post">
        <label for="deviceName">Device Name</label>
        <select id="deviceName">
          <option value="DigitalPersona">DigitalPersona</option>
          <option value="Secugen">Secugen</option>
          <option value="TwoPrintFutronic">TwoPrintFutronic</option>
          <option value="TenPrintFutronic">TenPrintFutronic</option>
          <option value="TwoPrintWatsonMini">TwoPrintWatsonMini</option>
          <option value="TenPrintWatsonMini">TenPrintWatsonMini</option>
          <option value="HitachiFV">HitachiFV</option>
          <option value="CMitech">CMitech</option>
          <option value="Face">Face</option>
        </select>
        <br><label for="engineName">Engine Name</label>
        <select id="engineName">
          <option value="FPFF02">FingerPrint</option>
          <option value="FVHT01">FingerVein</option>
          <option value="IRIS01">Iris</option>
          <option value="FACE01">Face</option>
        </select>
        <br><label for="templateFormat">Template Format</label>
        <select id="templateFormat">
          <option value="ISO">ISO</option>
          <option value="ICS">ICS</option>
          <option value="ANSI">ANSI</option>
          <option value="FP2">FP2</option>
          <option value="FP1">FP1</option>
          <option value="M2ICS">M2ICS</option>
        </select>
        <br>
        <button onClick="javascript:setConfiguration()" class="btn btn-primary">Set Active Device</button>
        <label id="lblMessage"></label><br>
        Please note: This function doesn't return any data. It just works.
      </form>
    </div>
  </div>
  <script>
  function backToHome() {
    window.location.href = "<?=$us_url_root?>users/admin.php?view=plugins_config&plugin=fingerprint";
  }
</script>
</body>
</html>
