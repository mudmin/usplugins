<?php if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted
global $user,$us_url_root,$abs_us_root,$db;
if(pluginActive('fingerprint')){ ?>
<?php
include $abs_us_root.$us_url_root.'usersc/plugins/fingerprint/login.php';
} //end plugin active ?>
