<?php
require_once '../../../users/init.php';
if(!hasPerm([2],$user->data()->id)){die("invalid token");}
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
require 'web.config.php';
use CloudABISSampleWebApp_CloudABIS\CloudABISConnector;
function LoadCloudABISToken()
{
  $cloudABISConnector = new CloudABISConnector(CloudABISAppKey, CloudABISSecretKey, CloudABIS_API_URL, CloudABISCustomerKey, ENGINE_NAME);

  $token = $cloudABISConnector->GetCloudABISToken();
  if ( ! is_null($token) && isset($token->access_token) != "" )
  {
    $_SESSION['access_token'] = $token->access_token;
    //SessionManager.CloudABISAPIToken = token.AccessToken;
    //SessionManager.CloudABISCredentials = cloudABISCredentials;
  }
  else
  {
    die("CloudABIS Not Authorized!. Please check credentails");
  }
}

LoadCloudABISToken();

?>
<script src="scripts/CloudABIS-ScanR.js"></script>
<script src="scripts/CloudABIS-Helper.js"></script>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>IsRegister Form</title>
</head>
<body>
  <?php require 'headermenu.php';?>
  <h1 class="headline">Check if a User ID exists in the CloudAbis DB</h1>

  <div class="row">
    <div class="col-12 text-center">
      <div class="formWrapper">
        <form class="commonForm" action="" method="POST">
          <br>
          <label for="ID">ID:</label>
          <input type="text" name="txtID" id="txtID" value="">
          <input type="submit" name="submit" value="Check" class="btn btn-primary">

        </form>
      </div>
    </div>
  </div>
  <?php
  function SetStatus($message)
  {
    echo '<h3 class="sresponse"> Server response: '.$message.'</h3>';
  }
  ?>

  <?php

  if ( isset($_POST['submit']) ) {
    if ( $_POST['txtID'] != "" ) {
      $regID = $_POST['txtID'];
      try
      {
        if ( $regID != "" )
        {
          $regID = trim($regID);

          if ( isset($_SESSION['access_token']) && $_SESSION['access_token'] != "" )
          {
            $cloudABISConnector = new CloudABISConnector(CloudABISAppKey, CloudABISSecretKey, CloudABIS_API_URL, CloudABISCustomerKey, ENGINE_NAME);

            $lblMessageText = $cloudABISConnector->IsRegister($regID, $_SESSION['access_token']);
            SetStatus($lblMessageText);
          }
          else
          {
            die("missing access token");
          }
        }
        else SetStatus("Please give an ID");
      }
      catch (Exception $ex)
      {
        SetStatus($ex->Message());
      }
    }
    else {
      SetStatus("Please put registration id");
    }
  }
  ?>
</div>
<script>
function backToHome() {
  window.location.href = "<?=$us_url_root?>users/admin.php?view=plugins_config&plugin=fingerprint";
}
</script>
<?php   include 'userslist.php'; ?>
</body>
</html>
