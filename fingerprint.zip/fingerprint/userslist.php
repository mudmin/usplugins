<?php if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted
$db = DB::getInstance();
global $us_url_root;
?>
<div class="row">
<div class="col-12">
  <h3>Existing users (to search for ids)</h3>
  <?php $users = $db->query("SELECT * FROM users")->results();?>
  <table class="table table-striped paginate">
    <thead>
      <tr>
        <th>ID</th><th>Username</th><th>First Name</th><th>Last Name</th>
      </tr>
    </thead>
    <tbody>
      <?php $users = $db->query("SELECT * FROM users")->results();
      foreach ($users as $u) { ?>
        <tr>
          <td><?=$u->id?></td>
          <td><?=$u->username?></td>
          <td><?=$u->fname?></td>
          <td><?=$u->lname?></td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
</div>
</div>
<script type="text/javascript" src="<?=$us_url_root?>users/js/pagination/datatables.min.js"></script>
<script>
$(document).ready(function () {
   $('.paginate').DataTable({"pageLength": 25,"stateSave": true,"aLengthMenu": [[25, 50, 100, -1], [25, 50, 100, 250, 500]], "aaSorting": []});
  });
</script>
