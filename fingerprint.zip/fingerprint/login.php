<?php
/*
UserSpice 5
An Open Source PHP User Management System
by the UserSpice Team at http://UserSpice.com

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
// require_once '../../../users/init.php';
// $db = DB::getInstance();
$settings = $db->query("SELECT * FROM settings")->first();
if(isset($user) && $user->isLoggedIn()){
	Redirect::to($us_url_root.'index.php');
}
require 'web.config.php';
use CloudABISSampleWebApp_CloudABIS\CloudABISConnector;
// require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
if(pluginActive('fingerprint')){
	function LoadCloudABISToken()
	      {

	          // CloudABISAPICredentials cloudABISCredentials = new CloudABISAPICredentials();
	          // cloudABISCredentials.AppKey = AppSettingsReader.CloudABISAppKey;
	          // cloudABISCredentials.SecretKey = AppSettingsReader.CloudABISSecretKey;
	          // cloudABISCredentials.BaseAPIURL = AppSettingsReader.CloudABIS_API_URL;
	          // cloudABISCredentials.CustomerKey = AppSettingsReader.CloudABISCustomerKey;
	          // cloudABISCredentials.EngineName = EngineName();

	          //Read token from CloudABIS Server
	          $cloudABISConnector = new CloudABISConnector(CloudABISAppKey, CloudABISSecretKey, CloudABIS_API_URL, CloudABISCustomerKey, ENGINE_NAME);

	          $token = $cloudABISConnector->GetCloudABISToken();
	          if ( ! is_null($token) && isset($token->access_token) != "" )
	          {
	              $_SESSION['access_token'] = $token->access_token;
	              //SessionManager.CloudABISAPIToken = token.AccessToken;
	              //SessionManager.CloudABISCredentials = cloudABISCredentials;
	          }
	          else
	          {
	              die("CloudABIS Not Authorized!. Please check credentails");
	          }
	      }

	      LoadCloudABISToken();
?>
<script src="<?=$us_url_root?>usersc/plugins/fingerprint/scripts/CloudABIS-ScanR.js"></script>
<script src="<?=$us_url_root?>usersc/plugins/fingerprint/scripts/CloudABIS-Helper.js"></script>
<?php
function SetStatus($message)
{
		echo '<h3 class="sresponse"> Server response: '.$message.'</h3>';
}

if (isset($_POST['identify'])) {
		    if ($_POST['identify'] != "") {
		        $templateXML = $_POST['templateXML'];
		        if (isset($_COOKIE['CSTempalteFormat'])) {
		            $templateFormat = $_COOKIE['CSTempalteFormat'];
		        }

		        try
		        {
		            if ($templateXML != "") {
		                if (isset($_SESSION['access_token']) && $_SESSION['access_token'] != "") {
		                    $cloudABISConnector = new CloudABISConnector(CloudABISAppKey, CloudABISSecretKey, CloudABIS_API_URL, CloudABISCustomerKey, ENGINE_NAME);
		                    $lblMessageText = $cloudABISConnector->Identify($templateXML, $_SESSION['access_token'], $templateFormat);
		                    // SetStatus($lblMessageText);
													if(is_numeric($lblMessageText) && $lblMessageText > 0){
													$id = trim($lblMessageText);
													$checkQ = $db->query("SELECT id FROM users WHERE id = ?",[$id]);
													$checkC = $checkQ->count();
													if($checkC > 0){
														$_SESSION['user'] = $id;
														// include $abs_us_root.$us_url_root.'usersc/scripts/custom_login_script.php';
														Redirect::to($us_url_root.'index.php');

												}
											}else{
												Redirect::to($us_url_root.'users/login.php?msg=Invalid');
											}
											}else {
		                  die("Something went wrong");
		                    // die("missing access token");
		                }
		            } else {
		                SetStatus("Problem in biometric template data");
										die(2);
		            }
		        } catch (Exception $ex) {
		            SetStatus($ex->Message());
								die(3);
		        }
		    } else {
		        SetStatus("Please put registration id");
		    }
		}



		?>
<script type="text/javascript">
    function setConfiguration() {
			console.log("triggered");
        var engineName = document.getElementById("engineName");
        engineName = engineName.options[engineName.selectedIndex].value;
        var templateFormat = document.getElementById("templateFormat");
        templateFormat = templateFormat.options[templateFormat.selectedIndex].value;

        var deviceName = document.getElementById("deviceName");
        deviceName = deviceName.options[deviceName.selectedIndex].value;

        if ( engineName != '' ) {
            //set credentials in cookey or any others client storage or get your storage
            setCookie("CSDeviceName", deviceName, 7);
            setCookie("CABEngineName", engineName, 7);
            setCookie("CSTempalteFormat", templateFormat, 7);

            // window.location.href = "<?php //$us_url_root?>usersc/plugins/fingerprint/login.php";
        } else {
            failCall("Please put required values.");
        }

    }

    function setCookie(name, value, days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "") + expires + "; path=/";
    }
    function failCall(status) {
        document.getElementById('lblMessage').innerHTML = status;
    }
</script>



<?php
//php goes here
?>

<div id="page-wrapper">
	<div class="container">
		<div class="row">
		  <div class="col-12 col-sm-6">
		    <form class="commonForm" action="" method="POST">
		        <h1 class="headline">Login With Fingerprint</h1>
		        <div class="mt-10">
		            <label>Capture Type:</label>
		            <select name="captureType" id="captureType">
		                <option value="SingleCapture">Single Capture</option>
		                <option value="DoubleCapture">Double Capture</option>
		            </select>
		        </div>
		        <div class="mt-10">
		            <label>Quick Scan:</label>
		            <select name="quickScan" id="quickScan">
		                <option value="Enable">Enable</option>
		                <option value="Disable">Disable</option>
		            </select>
		        </div>
		        <div>
		            <label id="lblCurrentDeviceName"></label>
		            <input type="button" name="biometricCapture" value="Biometric Capture" onclick="captureBiometric()" class="btn btn-success">
		            <input type="submit" name="identify" value="Identify" class="btn btn-primary">
		        </div>

		        <input type="hidden" name="templateXML" id="templateXML" value="">
		    </form>
		    <label id="serverResult"></label>
		  </div>

		  <div class="col-12 col-sm-6">
		    <div class="iholder">
		        <h1 class="headline">Select New Biometric Device</h1>
		        Only if login does not work.

		        <label for="deviceName">Device Name</label>
		        <select id="deviceName">
								<option value="DigitalPersona">DigitalPersona</option>
								<option value="Secugen">Secugen</option>
		            <option value="TwoPrintFutronic">TwoPrintFutronic</option>
		            <option value="TenPrintFutronic">TenPrintFutronic</option>
		            <option value="TwoPrintWatsonMini">TwoPrintWatsonMini</option>
		            <option value="TenPrintWatsonMini">TenPrintWatsonMini</option>
		            <option value="HitachiFV">HitachiFV</option>
		            <option value="CMitech">CMitech</option>
		            <option value="Face">Face</option>
		        </select>
		        <br><label for="engineName">Engine Name</label>
		        <select id="engineName">
		            <option value="FPFF02">FingerPrint</option>
		            <option value="FVHT01">FingerVein</option>
		            <option value="IRIS01">Iris</option>
		            <option value="FACE01">Face</option>
		        </select>
		        <br><label for="templateFormat">Template Format</label>
		        <select id="templateFormat">
		            <option value="ISO">ISO</option>
		            <option value="ICS">ICS</option>
		            <option value="ANSI">ANSI</option>
		            <option value="FP2">FP2</option>
		            <option value="FP1">FP1</option>
		            <option value="M2ICS">M2ICS</option>
		        </select>
		        <br><br><button onClick="javascript:setConfiguration()" class="btn btn-primary">Set Active Device</button><br><br>
		        <label id="lblMessage"></label>
		    </div>
		  </div>

		</div>



		<?php

		?>


		<?php }else{
			echo "Plugin not active";
		}?>
	</div>
</div>


<?php require_once $abs_us_root . $us_url_root . 'users/includes/html_footer.php'; ?>
