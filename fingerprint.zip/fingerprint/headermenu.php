<?php if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted ?>
<div class="row">
  <div class="col-12">
    <div class="text-center">
      <button class="btn btn-primary" onclick="window.location.href='<?=$us_url_root?>usersc/plugins/fingerprint/IsRegister.php'">IsRegistered</button>
      <button class="btn btn-primary" onclick="window.location.href='<?=$us_url_root?>usersc/plugins/fingerprint/ChangeID.php'">ChangeID</button>
      <button class="btn btn-primary" onclick="window.location.href='<?=$us_url_root?>usersc/plugins/fingerprint/DeleteID.php'">DeleteID</button>
      <button class="btn btn-primary" onclick="window.location.href='<?=$us_url_root?>usersc/plugins/fingerprint/Register.php'">Register</button>
      <button class="btn btn-primary" onclick="window.location.href='<?=$us_url_root?>usersc/plugins/fingerprint/Identify.php'">Identify</button>
      <button class="btn btn-primary" onclick="window.location.href='<?=$us_url_root?>usersc/plugins/fingerprint/Verify.php'">Verify</button>
      <button class="btn btn-primary" onclick="window.location.href='<?=$us_url_root?>usersc/plugins/fingerprint/UpdateFP.php'">Update</button>
      <button class="btn btn-primary" onclick="window.location.href='<?=$us_url_root?>usersc/plugins/fingerprint/ActiveDevice.php'">Change active device</button>
    </div>
  </div>
</div>
