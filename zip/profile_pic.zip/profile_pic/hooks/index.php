<?php die("no browsing");
