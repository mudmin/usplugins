<style media="screen">
  .img-thumbnail{
    max-width:120px !important;
    max-height:150px !important;
  }
</style>
