<?php if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted ?>
You can include a link or logo or whatever you want here. This is loginbody.php
