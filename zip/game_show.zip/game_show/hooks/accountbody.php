<?php if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted ?>
<p>
  <a class="btn btn-primary btn-block" href="<?=$us_url_root?>game.php">Game Show</a>
</p>
