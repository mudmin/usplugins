<style media="screen">
  body{
    background-color:black;
    height: 100vh;
    width: 99vw;
    overflow:hidden !important;
    padding-left: .5vw;
    padding-right: .5vw;
    padding-top: .5vh;
    padding-bottom: .5vh;
  }

  .buzzer{
    height: 44vh;
    border-radius:5%;
    border: 5px solid black;
  }

  .buttons{
    height: 6vh;
  }

  .iconleft{
    margin-left: 1em;
  }

  .counter{
    font-size:5rem;
  }

  .lockicon{
    width:3vw;
    height: 3vw;
    padding: .5rem;
    background-color: black;
    border-radius:20%;
  }

  .counter{
    font-size: 4rem;
  }

</style>
