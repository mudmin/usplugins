<?php
$plugin_name = "getsettings"; 
 ?>
