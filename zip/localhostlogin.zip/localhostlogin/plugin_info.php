<?php
$plugin_name = "localhostlogin"; 
 ?>
