<?php if(isLocalhost()) {?>
<div class="text-center mt-3">
  <a href="../usersc/plugins/localhostlogin/files/index.php" class="btn btn-sm btn-outline-secondary">
    <i class="fas fa-laptop-code"></i> Localhost Login
  </a>
</div>
<?php } ?>
