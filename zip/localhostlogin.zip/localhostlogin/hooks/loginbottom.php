<?php if(isLocalhost()) {?><a href="../usersc/plugins/localhostlogin/files/index.php">[Localhost Login]</a><?php } ?>
