<?php
global $user;
dump($user->data()->email);
