<?php
if(file_exists("fb-callback.php")){
    include "fb-callback.php";
}