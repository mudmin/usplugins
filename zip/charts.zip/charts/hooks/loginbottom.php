<?php if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted?>
Hey look, I'm in the bottom of the login page. (This is loginform.php)<br><br>
