<?php if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted?>
What is your favorite color? (This is loginform.php)
<input class="form-control" type="color" name="color" value="">
