<?php
require_once "../../../users/init.php";
require_once $abs_us_root.$us_url_root.'users/includes/template/prep.php';
$ruleset = 1;
require_once $abs_us_root . $us_url_root . "usersc/plugins/handfoot/game.php";
require_once $abs_us_root.$us_url_root.'users/includes/html_footer.php'; 
