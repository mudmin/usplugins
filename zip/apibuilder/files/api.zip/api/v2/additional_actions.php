<?php
if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted
//include "includes/globals.php";
//if you create a file in
//usersc/api/{api version}/additional_actions.php"
//you can declare any other actions you want to be available to your api
