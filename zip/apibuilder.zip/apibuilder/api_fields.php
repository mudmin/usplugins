<?php
$hiddenFields[] = 'apibld_key';
$hiddenFields[] = 'apibld_ip';
$hiddenFields[] = 'apibld_blocked';
