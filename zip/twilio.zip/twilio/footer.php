<?php
//Please don't load code on the footer of every page if you don't need it on the footer of every page.
//bold("<br>Twilio Footer Loaded");
