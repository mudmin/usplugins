<?php
// For security purposes, it is MANDATORY that this page be wrapped in the following
// if statement. This prevents remote execution of this code.
include "plugin_info.php";
if (in_array($user->data()->id, $master_account) && pluginActive($plugin_name,true)){
//all actions should be performed here.

//check which updates have been installed
$count = 0;
$db = DB::getInstance();

//Make sure the plugin is installed and get the existing updates
$checkQ = $db->query("SELECT id,updates FROM us_plugins WHERE plugin = ?",array($plugin_name));
$checkC = $checkQ->count();
if($checkC > 0){
  $check = $checkQ->first();
  if($check->updates == ''){
  $existing = []; //deal with not finding any updates
  }else{
  $existing = json_decode($check->updates);
  }

  //list your updates here from oldest at the top to newest at the bottom.
  //Give your update a unique update number/code.

  //here is an example
  $update = '00001';
  if(!in_array($update,$existing)){
  logger($user->data()->id,"Migrations","$update migration triggered for $plugin_name");
//   $files = [
//     "_form_create_field.php",
//     "_form_edit_field.php",
//   ];
//   foreach($files as $file){
//     if(file_exists($abs_us_root.$us_url_root."usersc/plugins/forms/files/".$file)){
//       unlink($abs_us_root.$us_url_root."usersc/plugins/forms/files/".$file);
//     }
//   if (!copy($abs_us_root.$us_url_root."usersc/plugins/forms/files/".$file, $abs_us_root.$us_url_root."usersc/plugins/forms/files/".$file)) {
//       echo "failed to copy $file...\n";
//   		$cpyfail=1;
//   }
// }
//DEPRECATED
  $existing[] = $update; //add the update you just did to the existing update array
  $count++;
  }

  $update = '00002';
  if(!in_array($update,$existing)){
  //repeating this becaus 00001 was originally broken.
  logger($user->data()->id,"Migrations","$update migration triggered for $plugin_name");

//DEPRECATED
  $existing[] = $update; //add the update you just did to the existing update array
  $count++;
  }


  $update = '00003';
  if(!in_array($update,$existing)){
  $db->query("ALTER TABLE us_forms ADD COLUMN api_insert tinyint(1) DEFAULT 0");
  $db->query("ALTER TABLE us_forms ADD COLUMN api_update tinyint(1) DEFAULT 0");
  $db->query("ALTER TABLE us_forms ADD COLUMN api_perms_insert varchar(255) DEFAULT '2'");
  $db->query("ALTER TABLE us_forms ADD COLUMN api_perms_update varchar(255) DEFAULT '2'");
  logger($user->data()->id,"Migrations","$update migration triggered for $plugin_name");

  $existing[] = $update; //add the update you just did to the existing update array
  $count++;
  }

  $update = '00004';
  if(!in_array($update,$existing)){
  $db->query("ALTER TABLE us_forms ADD COLUMN api_user_col varchar(255) DEFAULT ''");
  $db->query("ALTER TABLE us_forms ADD COLUMN api_force_user_col tinyint(1) DEFAULT '1'");

  logger($user->data()->id,"Migrations","$update migration triggered for $plugin_name");

  $existing[] = $update; //add the update you just did to the existing update array
  $count++;
  }

  //after all updates are done. Keep this at the bottom.
  $new = json_encode($existing);
  $db->update('us_plugins',$check->id,['updates'=>$new,'last_check'=>date("Y-m-d H:i:s")]);
  if(!$db->error()) {
    logger($user->data()->id,"Migrations","$count migration(s) susccessfully triggered for $plugin_name");
  } else {
   	logger($user->data()->id,"USPlugins","Failed to save updates, Error: ".$db->errorString());
  }
}//do not perform actions outside of this statement
}
