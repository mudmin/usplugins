<?php if(count(get_included_files()) ==1) die();
//you can edit this to put any sort of custom instructions for check payments
?>
Please mail a check for a total of <font color="red">$<?=$formInfo['total']?></font> to:<br>
123 No Way<br>
Spiceville, FL 01234<br>
You must click submit to complete your order!<br><br>
