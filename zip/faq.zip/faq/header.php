<?php
if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted

//To add a link to the navigation menu, you can add the following code to your theme's navigation file.
//For the default theme, this is located at usersc/includes/navigation.php

// echo '<li><a href="'.$us_url_root.'usersc/plugins/faq/faq.php"><i class="fa fa-fw fa-question-circle"></i> FAQ</a></li>';

//Please note that this is just an example and you may need to modify it to fit your theme.
?>
