<?php
require_once '../../../users/init.php';
require_once $abs_us_root . $us_url_root . 'users/includes/template/prep.php';
require_once $abs_us_root . $us_url_root . 'usersc/plugins/faq/faq_body.php';
require_once $abs_us_root . $us_url_root . 'users/includes/html_footer.php'; 

?>