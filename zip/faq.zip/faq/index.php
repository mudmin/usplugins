<?php 
require_once '../../../users/init.php'; 
Redirect::to("faq.php");