<?php 
function displayFAQ(){
    global $abs_us_root, $us_url_root, $db, $settings;
    require_once $abs_us_root . $us_url_root . 'usersc/plugins/faq/faq_body.php';
}

