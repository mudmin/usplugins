<?php /* UserSpice AI Prompt — protected from HTTP access. Markdown content below. */ __halt_compiler(); ?>

# UserSpice — The Secure Page Pattern

Load this when you're writing the actual code for a page, form handler, or AJAX endpoint. This is the canonical recipe — every shipped UserSpice page follows it, and `/userspice-audit` will flag pages that don't.

For a fresh page, prefer **`/userspice-page-scaffold`** — it generates this pattern correctly the first time, including the variations for form-with-handler and AJAX parser. The patterns below explain *what the scaffold does* and *how to read or audit existing code*.

---

## The skeleton (a guarded page with no form)

Every UserSpice page starts with these three lines, in this order:

```php
<?php
require_once '../users/init.php';
require_once $abs_us_root . $us_url_root . 'users/includes/template/prep.php';
if (!securePage($_SERVER['PHP_SELF'])) { die(); }
?>
```

What each line does:

1. **`users/init.php`** — bootstraps the framework. After this line, `$db`, `$user`, `$settings`, `$config`, `$abs_us_root`, `$us_url_root`, and all framework classes/helpers exist.
2. **`prep.php`** — wires the active template (header/footer, nav, system messages). Pages that opt out of the template (raw JSON endpoints, downloads) skip this line.
3. **`securePage()`** — checks that the visitor is allowed to view this page given the registered permissions in the `permission_page_matches` table. Returns false → `die()`. If you don't call this, the page is wide open.

### Path conventions: `$abs_us_root . $us_url_root` for filesystem, `$us_url_root` for URLs

These two globals exist for a reason — UserSpice can be installed at the document root *or* at any subpath (`/userspice/`, `/myapp/`, `/clientname/`), and every path in the codebase has to keep working in both cases.

- **`$abs_us_root`** is the absolute filesystem path to the document root, e.g. `/var/www/html/`.
- **`$us_url_root`** is the URL path from the document root to the UserSpice install root, e.g. `/myapp/` (or just `/` if installed at the doc root). It always ends with a slash.
- **Together**, `$abs_us_root . $us_url_root` is the absolute filesystem path to the UserSpice install root — e.g. `/var/www/html/myapp/`.

That gives the canonical patterns:

```php
// ✓ require_once / include — absolute filesystem path
require_once $abs_us_root . $us_url_root . 'usersc/includes/loader.php';
require_once $abs_us_root . $us_url_root . 'admin/widgets/foo.php';

// ✓ ANY URL emitted to the browser — link, src, href, redirect target
//   (forms normally have NO action — they self-post; see "Self-post" below)
<link rel="stylesheet" href="<?= $us_url_root ?>assets/site.css">
<a href="<?= $us_url_root ?>account.php">Account</a>
<img src="<?= $us_url_root ?>uploads/foo.jpg">
Redirect::to($us_url_root . 'account.php');
```

The **only** exception to the `$abs_us_root . $us_url_root` rule for includes is the bootstrap line itself — `require_once '../users/init.php'` (or `'users/init.php'` from the root) — because those two globals don't exist *until* init.php runs.

```php
// 🚨 Wrong — works at runtime but isn't the framework idiom
require_once __DIR__ . '/../includes/header.php';
require_once dirname(__FILE__) . '/../usersc/includes/foo.php';

// 🚨 Wrong — breaks the moment the site is installed at a subpath
<a href="/account.php">Account</a>            // hardcoded root
<a href="../account.php">Account</a>          // relative — different per page depth
<link href="/myapp/style.css" rel="stylesheet">  // hardcoded subpath
```

If you find yourself reaching for `__DIR__`, `dirname(__FILE__)`, or `realpath()` to build an include path inside a UserSpice page, stop — you almost certainly want `$abs_us_root . $us_url_root . '...'` instead. The same applies to hardcoded URL paths: if you typed a literal `/` at the start of an href or src, you're going to break someone's subpath install. Use `$us_url_root` and the page will work everywhere.

### The relative `../` for init.php

The relative path `'../users/init.php'` assumes the page lives one directory below the project root. From the root itself it's `'users/init.php'`. From two levels deep, `'../../users/init.php'`. Don't try to be clever — the framework expects this exact shape.

---

## Page with a form (the full recipe)

```php
<?php
require_once '../users/init.php';
require_once $abs_us_root . $us_url_root . 'users/includes/template/prep.php';
if (!securePage($_SERVER['PHP_SELF'])) { die(); }

// 1. Handle the POST if there is one
if (Input::exists()) {
    // 2. CSRF first, before anything else
    if (!Token::check(Input::get('csrf'))) {
        usError(lang('TOKEN_ERROR'));
        Redirect::to($us_url_root . 'account.php');
    }

    // 3. Validate
    $validate = new Validate();
    $validate->check($_POST, [
        'name'  => ['display' => 'Name',  'required' => true, 'min' => 2, 'max' => 80],
        'email' => ['display' => 'Email', 'required' => true, 'valid_email' => true],
    ]);

    if ($validate->passed()) {
        // 4. Bound parameters — never interpolate user input
        global $db; // (only needed inside functions; here we're at global scope, but harmless)
        $db->insert('contacts', [
            'name'  => Input::get('name'),
            'email' => Input::get('email'),
        ]);
        usSuccess('Saved.');
        Redirect::to($us_url_root . 'contacts.php');
    } else {
        // Errors get rendered below
    }
}
?>

<!-- 5. Render the form. tokenHere() emits the CSRF hidden input. -->
<form method="post">
    <?= tokenHere(); ?>
    <label>Name <input type="text" name="name" value="<?= safeReturn(Input::get('name')) ?>"></label>
    <label>Email <input type="email" name="email" value="<?= safeReturn(Input::get('email')) ?>"></label>
    <button type="submit">Save</button>
</form>

<?php
if (!empty($validate) && !$validate->passed()) {
    echo $validate->display_errors();
}
?>
```

The order matters: **CSRF → validate → write → redirect**. Each step gates the next. If the CSRF check fails, never proceed to validation. If validation fails, never write. After a successful write, redirect (so refresh doesn't double-submit).

### Self-post — leave the form `action` empty

Notice the form above has **no `action` attribute**. That's deliberate. A form with no action (or an explicit `action=""`) submits to the page's own URL — which is exactly what this recipe expects, because the POST handler lives at the top of the *same file*. Both forms are equivalent:

```php
<form method="post">           <!-- ✓ self-posts to this page -->
<form action="" method="post"> <!-- ✓ also fine — explicit self-post -->
```

Use whichever you prefer (omitting is valid HTML; `action=""` signals intent more loudly). What you must **not** do is hand-write a path into the action:

```php
<form action="contacts.php">                    <!-- 🚨 the rewriter strips .php — this 404s or misroutes -->
<form action="<?= $us_url_root ?>contacts.php"> <!-- 🚨 posts to the wrong page unless you truly mean to -->
<form action="parsers/save.php">                <!-- 🚨 hit a parser with $.ajax, not a form action -->
<form action="#">                               <!-- 🚨 appends a fragment instead of self-posting -->
<form action=".">                               <!-- 🚨 resolves to the directory, not this page -->
```

UserSpice's `.php`-stripping URL rewriter plus subpath installs (`/myapp/`, `/clientname/`) make hand-built action URLs wrong far more often than right — a wrong action either 404s the POST or routes it to the wrong handler. The form just needs to post back to itself, and an empty action does that on every install path. The **only** time you set a real action is when the form genuinely targets a *different* page (rare); for AJAX, post to a `parsers/` endpoint with `$.ajax({url: 'parsers/x.php'})`, never a form action.

---

## AJAX endpoint (the `parsers/` folder)

UserSpice's URL rewriter strips `.php` from page URLs — but **exempts** anything under a `parsers/` folder. AJAX endpoints MUST live there or they'll either 404 or get routed somewhere unexpected.

A parser is a **separate request**. It inherits nothing from the page that called it — not session-derived auth, not page-level permission checks. **Every parser re-does the full auth dance.**

```php
<?php
// admin/parsers/delete_item.php
require_once '../../users/init.php';
header('Content-Type: application/json');

// 1. CSRF first — fail loud, fail early
if (!Token::check(Input::get('csrf_token'))) {
    http_response_code(403);
    die(json_encode(['success' => false, 'message' => 'Invalid CSRF token.']));
}

// 2. Same page-access check as the parent page
if (!securePage($_SERVER['PHP_SELF'])) { exit; }

// 3. Same permission check as the parent page (hasPerm() is a global helper, not a User method)
if (!hasPerm(2)) {
    http_response_code(403);
    die(json_encode(['success' => false, 'message' => 'Forbidden.']));
}

// 4. Cast IDs to int, validate ranges
$id = (int)Input::get('id');
if ($id <= 0) {
    http_response_code(400);
    die(json_encode(['success' => false, 'message' => 'Bad id.']));
}

// 5. Bound query
$db->query("DELETE FROM posts WHERE id = ?", [$id]);

echo json_encode(['success' => true]);
```

Calling from the page:

```javascript
$.ajax({
    url: 'parsers/delete_item.php',
    method: 'POST',
    data: { csrf: $('input[name="csrf"]').val(), id: itemId },
    dataType: 'json',
});
```

---

## The non-negotiable helpers

If you write any of these patterns the "raw PHP" way, your code is wrong:

| Don't | Do | Why |
|---|---|---|
| `$_POST['x']` / `$_GET['x']` | `Input::get('x')` | Trims + escapes, recursively sanitizes arrays |
| `$_SERVER['HTTP_HOST']` | `Server::get('HTTP_HOST')` | Type-checked, sanitized, works in CLI |
| `$_SERVER['REMOTE_ADDR']` | `ipCheck()` for logs, rate limits, bans; `ClientIP::peer()` for an IP allowlist that is the only gate | `ipCheck()` resolves the visitor through the trusted proxies in Admin → Proxy & CDN; `peer()` is the raw connection, never header-derived |
| `$_SERVER['HTTPS']` / `$ip === '127.0.0.1'` | `ClientIP::isHttps()` / `ClientIP::isLocal()` | Correct behind a TLS-terminating proxy, same-server proxy, or Cloudflare Tunnel |
| `htmlspecialchars($v)` | `safeReturn($v)` | Same escaping + understood by the Psalm taint analyzer |
| In JS: `<?= json_encode($v) ?>` | `<?= safeJsonEncodeForJs($v) ?>` | Escapes `<`, `>`, `&`, `'`, `"` so it can't break out of the script tag |
| `header('Location: ' . $_GET['next'])` | `Redirect::sanitized(Input::get('next'), null, 302, ['same_origin' => true])` | Strips CRLF, blocks `//evil.com` and `javascript:` |
| `header('Location: account.php')` | `Redirect::to('account.php')` | Same protections, exits cleanly, has CSP-nonced fallback if headers already sent |
| `md5(uniqid())` / `mt_rand()` for tokens | `Hash::unique()` | CSPRNG — `uniqid()` is clock-derived and guessable |
| String concatenation in SQL | `$db->query("... WHERE x = ?", [$x])` | Prepared statements with bound values |
| Plaintext API keys in DB | `spiceEncrypt($v)` / `spiceDecrypt($blob, '', '')` | AES-256-GCM, authenticated |
| Ad-hoc `if (!empty($x) && ...)` chains | `new Validate(); $v->check($_POST, $rules)` | Collects all errors, integrates with the flash banner system |

When you don't know the exact signature of one of these helpers, run **`/userspice-helper-lookup <name>`**.

---

## SQL identifiers and `LIMIT`/`OFFSET` — the one place placeholders don't help

PDO placeholders only bind *values*. Table names, column names, sort directions, and `LIMIT`/`OFFSET` cannot be bound. The driver also quotes bound values as strings, so MySQL rejects `LIMIT '10'` as a syntax error.

**Never interpolate user input into those positions.** Two safe patterns:

```php
// Whitelist identifiers
$allowedCols = ['id', 'title', 'created_at'];
$allowedDirs = ['ASC', 'DESC'];

$col = in_array(Input::get('sort'), $allowedCols, true)
    ? Input::get('sort') : 'id';
$dir = in_array(strtoupper(Input::get('dir')), $allowedDirs, true)
    ? strtoupper(Input::get('dir')) : 'DESC';

// Cast LIMIT/OFFSET to int in named variables FIRST, then interpolate
$page    = max(1, (int)Input::get('page', 1));
$perPage = (int)Input::get('per_page', 25);
$perPage = in_array($perPage, [10, 25, 50, 100], true) ? $perPage : 25;
$offset  = ($page - 1) * $perPage;

$rows = $db->query(
    "SELECT * FROM posts ORDER BY $col $dir LIMIT $offset, $perPage"
)->results();
```

The cast is what makes `LIMIT $offset, $perPage` safe. A string like `"10; DROP TABLE users"` casts to `10`. Non-numeric input becomes `0`. Always assign to a named variable so the cast is obvious at the call site — don't write `LIMIT (int)Input::get(...)` inline.

---

## `$db->insert()` and `$db->update()` return `bool`, not the ID or row count

This is the single most common API surprise for developers coming from Laravel, Eloquent, ActiveRecord, or any other ORM where the create/save method returns the model with the new primary key on it. **UserSpice's DB class doesn't.** Both `insert()` and `update()` return `true` on success and `false` on error. Nothing else.

To get the new auto-increment ID after an insert, call `$db->lastId()`. To get the affected row count after an update or delete, call `$db->count()`.

```php
// WRONG — $newId is bool true, not the new contact's ID. Foreign key now points at row 1.
$newId = $db->insert('contacts', ['name' => $name, 'email' => $email]);
$db->insert('contact_tags', ['contact_id' => $newId, 'tag' => 'lead']);

// RIGHT — separate calls
$db->insert('contacts', ['name' => $name, 'email' => $email]);
if (!$db->error()) {
    $newId = $db->lastId();
    $db->insert('contact_tags', ['contact_id' => $newId, 'tag' => 'lead']);
}

// Update returns bool too. Affected row count is on $db->count() afterward.
$db->update('users', $userId, ['email' => $newEmail]);
if (!$db->error()) {
    $rowsChanged = $db->count();   // 0 if email was already $newEmail; 1 if it actually changed
}
```

The `if (!$db->error())` guard matters — `$db->lastId()` and `$db->count()` reflect the *most recent query on this connection*. If the insert errored and you then ran another query before checking, `lastId()` would refer to whatever ran most recently. Check the error first, then read.

---

## Flash messages: `usError` / `usSuccess`

The framework has a banner system rendered by the template. Push a message, then redirect, and the user sees it on the next page:

```php
usError('Could not save your changes.');
Redirect::to($us_url_root . 'account.php');

// or
usSuccess('Profile updated.');
Redirect::to($us_url_root . 'account.php');
```

Don't `echo` errors directly into the page — they won't follow the redirect and they don't get the standard styling.

---

## `Input::get()` and `Input::exists()` gotcha (worth re-reading)

`Input::get('foo')` returns `""` (empty string) when the key is missing — **not** `false`, **not** `null`. So:

```php
if (Input::get('foo') === false) { ... }   // never fires
if (Input::get('foo') === null) { ... }    // never fires
if (Input::get('foo') === '')   { ... }    // ✓ correct
if (empty(Input::get('foo')))   { ... }    // ✓ correct
```

### `Input::exists()` does NOT take a field name

This is the single most-mis-used helper in UserSpice. Read the signature in [users/classes/Input.php:21](users/classes/Input.php#L21):

```php
public static function exists($type = 'post'){
    switch ($type) {
        case 'post':   return (!empty($_POST)) ? true : false;
        case 'get':    return (!empty($_GET))  ? true : false;
        default:       return false;
    }
}
```

The argument is a **TYPE** (`'post'` or `'get'`), not a field name. The default case returns `false`. So:

```php
if (Input::exists('action')) { ... }       // 🚨 ALWAYS FALSE — 'action' is not a type
if (Input::exists('rehidden')) { ... }     // 🚨 ALWAYS FALSE
if (Input::exists('csrf_token')) { ... }   // 🚨 ALWAYS FALSE

if (Input::exists()) { ... }               // ✓ "is this a POST request?"
if (Input::exists('post')) { ... }         // ✓ same thing, explicit
if (Input::exists('get')) { ... }          // ✓ "are there any query params?"
```

To test whether a **specific field** is present, just use `Input::get()` and compare to the empty string (since that's what missing returns):

```php
// "did the user submit the form?"
if (Input::exists() && Input::get('action') === 'save') { ... }

// "was the rehide checkbox ticked?"
$rehidden = Input::get('rehidden') === '1' ? 1 : 0;

// "is there a search term?"
$q = Input::get('q');
if ($q !== '') { ... }
```

If you need a non-empty default, pass it as the second arg: `Input::get('page', 1)`.

If you've shipped a page that uses `Input::exists('some_field_name')` as a guard, the entire guarded block has been silently dead-code since day one. `/userspice-audit` will not catch this — it's a logic bug, not a security bug.

---

## Validate — the full rule reference

`Validate::check($source, $rules, $sanitize = false)` runs a declarative rule set against any source array. It collects *all* errors so the user sees them at once, and `display_errors()` returns Bootstrap-friendly markup that highlights the offending fields via jQuery.

The rules you'll actually use:

| Rule | What it checks | Example |
|---|---|---|
| `display` | Human label used in error messages (not a check) | `'display' => 'Email Address'` |
| `required` | Value present and non-empty | `'required' => true` |
| `min` / `max` | String length | `'min' => 8, 'max' => 128` |
| `matches` | Equal to another field's value | `'matches' => 'password'` (confirm-password) |
| `unique` | Doesn't exist in `{table}.{column}` (column = field name) | `'unique' => 'users'` |
| `unique_update` | Like `unique`, but ignores the row with this id | `'unique_update' => 'users.42'` |
| `valid_email` | Looks like an email | `'valid_email' => true` |
| `is_not_email` | Specifically *isn't* an email (anti-email field) | `'is_not_email' => true` |
| `is_numeric` / `is_num` | Numeric value | `'is_numeric' => true` |
| `is_integer` / `is_int` | Integer specifically | `'is_int' => true` |
| `<` / `>` / `<=` / `>=` / `!=` / `==` | Numeric comparison to a value | `'>' => 0, '<=' => 100` |
| `in` | Value is in a fixed set | `'in' => ['yes', 'no', 'maybe']` |
| `is_in_array` | Value is in a runtime-supplied array | `'is_in_array' => $allowedRoles` |
| `is_in_database` | Value exists in `{table}.{column}` | `'is_in_database' => 'categories.slug'` |
| `is_datetime` | Parseable as datetime | `'is_datetime' => true` |
| `is_timezone` | A valid PHP timezone string | `'is_timezone' => true` |
| `is_valid_north_american_phone` | Looks like a NA phone number | `'is_valid_north_american_phone' => true` |

Realistic example with several rules per field:

```php
$validate = new Validate();
$validate->check($_POST, [
    'username' => [
        'display'  => 'Username',
        'required' => true,
        'min'      => 3,
        'max'      => 30,
        'unique'   => 'users',
    ],
    'email'    => [
        'display'     => 'Email',
        'required'    => true,
        'valid_email' => true,
        'unique'      => 'users',
    ],
    'password' => [
        'display'  => 'Password',
        'required' => true,
        'min'      => 12,
        'max'      => 200,
    ],
    'confirm'  => [
        'display' => 'Confirm Password',
        'matches' => 'password',
    ],
    'role'     => [
        'display' => 'Role',
        'in'      => ['member', 'editor', 'admin'],
    ],
    'age'      => [
        'display' => 'Age',
        'is_int'  => true,
        '>'       => 12,
        '<'       => 130,
    ],
]);

if ($validate->passed()) {
    // safe to insert
} else {
    echo $validate->display_errors();
}
```

`display_errors()` outputs ready-styled markup — call it once at the bottom of the page (or near the form) and the user sees every problem at once.

---

## Embedding PHP values in JavaScript: `safeJsonEncodeForJs`

`json_encode()` alone is **not** safe for embedding inside a `<script>` block: a `</script>` substring inside a string literal can prematurely close the script tag, and `<!--` can start an HTML comment that swallows your code.

`safeJsonEncodeForJs($value)` wraps `json_encode()` with `JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP`, so `<`, `>`, `&`, `'`, and `"` come out as `\uXXXX` escapes that cannot terminate the surrounding script tag or break out of the string literal.

```php
<?php
$user = ['name' => $row->name, 'tags' => json_decode($row->tags_json, true)];
?>
<script>
  // Use safeJsonEncodeForJs for ANY value going into a <script> tag
  const currentUser = <?= safeJsonEncodeForJs($user) ?>;

  // Works for strings, arrays, objects, nested structures — anything json_encode handles
  const dangerousString = <?= safeJsonEncodeForJs("</script><img src=x>") ?>;
  // → "<\/script><img src=x>"  — harmless inside the script tag
</script>
```

Don't HTML-escape JSON via `safeReturn()` and embed it — that mangles the JSON. Don't roll your own with `addslashes()` either. Just use `safeJsonEncodeForJs()`.

---

## Rate-limit auth-adjacent endpoints

Every login, registration, password-reset, 2FA-verify, and "expensive write" endpoint should sit behind `RateLimit`:

```php
$rl = new RateLimit();
if (!$rl->check('login', ['ip' => ipCheck(), 'email' => $email])) {
    http_response_code(429);
    die('Too many attempts. Try again later.');
}
// ...attempt the auth...
$rl->record('login', ['ip' => ipCheck(), 'email' => $email], $success);
```

Limits are configured per-action in `usersc/includes/rate_limits.php`. The class sanitizes identifiers internally — don't pre-clean them.

The default action names that ship with limits configured: `login`, `register`, `forgot_password`, `verify_resend`, `totp_verify`, `passkey_login`. Add your own by editing `rate_limits.php`. The `record()` call's `$success` flag matters — failed attempts and total attempts have separate caps, so a successful login resets the failed-attempt counter for that identifier.

---

## Client IP, local requests, and HTTPS behind proxies

`$_SERVER['REMOTE_ADDR']` is the IP of whatever immediately connected to the web server. Behind a load balancer, CDN, or reverse proxy (Cloudflare, Nginx, Traefik, ELB), that's *the proxy*, not the actual user. The real client IP is in a forwarded header like `X-Forwarded-For` or `CF-Connecting-IP` — but you can only trust that header if it came from a proxy *you control*. Otherwise any visitor can spoof their IP by sending the header themselves.

UserSpice resolves this once, in the `ClientIP` class, using the trusted proxies configured in **Admin → Proxy & CDN** (`users/admin.php?view=proxy`, or `usersc/includes/trusted_proxies.php`). Don't pass proxy CIDRs around in page code. Pick the call by what the IP is *for*:

| Need | Use | Why |
|---|---|---|
| Logging, audit rows, rate limits, bans | `ipCheck()` (same as `ClientIP::get()`) | The resolved visitor. Forwarded headers count only from a configured trusted proxy. |
| An IP allowlist that is the only gate (cron or webhook endpoint, admin-by-IP) | `ClientIP::peer()` | The raw connection address, never header-derived, so it can't be spoofed with a header. |
| An IP allowlist that is a second check on top of a secret (e.g. a signed webhook) | `ipCheck()` | The secret is the real gate; the resolved IP keeps the check working behind a CDN. |
| "Is this request from this machine?" | `ClientIP::isLocal()` | True for CLI, or a loopback connection with no forwarding headers and a localhost Host. |
| "Is this request HTTPS?" | `ClientIP::isHttps()` | Honors `X-Forwarded-Proto` only from a trusted proxy. |

```php
// An allowlist that is the only gate: compare the connection, not a header
$allowed = ['203.0.113.10'];
if (!ClientIP::isLocal() && !in_array(ClientIP::peer(), $allowed, true)) {
    http_response_code(403);
    die('Forbidden');
}

// Require HTTPS, including behind Cloudflare or a load balancer that terminates TLS
if (!ClientIP::isHttps() && !ClientIP::isLocal()) {
    http_response_code(403);
    die('HTTPS required');
}
```

Never compare an IP to `'127.0.0.1'` or `'::1'` to decide a request is local or trusted. Behind a same-server proxy (Nginx in front of Apache or PHP-FPM) or a Cloudflare Tunnel, *every* visitor arrives from 127.0.0.1. Use `ClientIP::isLocal()`. For dev hostnames other than `localhost`, add `define('US_LOCAL_HOSTS', ['mysite.test']);` to `users/init.php`.

Don't read `$_SERVER['HTTPS']` directly either: it's empty when a proxy terminates TLS (Cloudflare Flexible SSL, a load balancer), so the check rejects every real visitor. `Server::getHost()` and `Server::getOrigin()` are still the way to read the host and origin.

`ClientIP` exists from UserSpice 6.1.6; `isLocal()` and `isHttps()` from 6.1.8. Code that must run on older cores should check `method_exists('ClientIP', 'isLocal')` first. `Server::getClientIp()` still works but is legacy; use `ipCheck()`.

---

## Audit before declaring done

Run **`/userspice-audit`** after writing or modifying a page. It walks every custom file (outside `users/`) and flags violations with file:line references. It does not modify code — it just tells you what to fix.

---

## Canonical reference

This prompt summarizes `userspice-best-practices/index.php`. Read that guide when you need the longer rationale (proxy CIDR handling, the double-encoding case for `safeReturn(..., true)`, the AES-256-GCM details, etc.).
