What is your favorite color? (This is loginform.php)
<input class="form-control" type="color" name="color" value="">
