<?php
//You can create your very own admin.php dashboard icon here
//Feel free to delete this file if you don't need it.

//here is an example.
?>
<a href="<?=$us_url_root?>users/dbman_settings.php"><div class="col-md-1 col-sm-3 col-sm-6 col-centered">
  <div class="panel panel-default">
    <i class="fa fa-microchip fa-2x"></i><br>DB Man</li>
  </div>
</div></a>
