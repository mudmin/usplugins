<?php
include($abs_us_root.$us_url_root.'usersc/plugins/mqtt/assets/phpMQTT.php');
