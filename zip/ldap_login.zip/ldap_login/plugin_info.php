<?php
//Use this file to define info that you want to use throughout your plugin. You must declare folder name and plugin name
$plugin_name = "ldap_login"; //should be the same as the folder name in all lowercase.
 ?>
