<?php
$plugin_name = "defaultrememberme"; 
 ?>
