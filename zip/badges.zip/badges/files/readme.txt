Place your badge files here.  They should be the badgeid.png
So badge 1 should be
1.png 
