<?php if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted Leave this line in place
global $v1;
?>
<td><?=pointsUnitReturn($v1->plg_points);?></td>
