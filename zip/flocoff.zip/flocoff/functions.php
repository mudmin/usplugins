<?php
header("Permissions-Policy: interest-cohort=()");
