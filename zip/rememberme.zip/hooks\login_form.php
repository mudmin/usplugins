<?php if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted ?>
<div class="form-group">
  <label for="remember">
    <input type="checkbox" name="remember" id="remember" > <?=lang("SIGNIN_REMEMBER")?></label>
</div>
