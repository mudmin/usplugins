<?php
$plgMessagesTheme = [
    'openMessageButtonBG' => '#dbdbdb', 
    'openMessageButton' => 'ms-2 me-2',
    'messageCountColor' => '#000', // Black text color
    'alertIcon' => 'fas pe-2 fa-lg fa-exclamation-circle text-danger',
    'notifIcon' => 'fas pe-2 fa-lg fa-bell text-warning',
    'messageIcon' => 'fas pe-2 fa-lg fa-envelope text-primary',
    'iconSizeSize' => 'font-size: 1.1rem;',
    'counterFontSize' => 'font-size: 1.1rem; line-height: 1.0;',
    
];