<?php if(count(get_included_files()) ==1) die(); //Direct Access Not Permitted ?>
<div class="row">
  <div class="col-12 text-center">
    <a class="" href="admin.php?view=plugins_config&plugin=saas"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
     -     <a class="" href="admin.php?view=plugins_config&plugin=saas&v=org"><i class="fa fa-bank-o" aria-hidden="true"></i> Configure Orgs</a>
     -     <a class="" href="admin.php?view=plugins_config&plugin=saas&v=plan"><i class="fa fa-file-powerpoint-o" aria-hidden="true"></i> Configure Plans</a>
  </div>
</div>
