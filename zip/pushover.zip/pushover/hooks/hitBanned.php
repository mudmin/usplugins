<?php
pushoverSecurityAlert('hitBanned', [
  'extra' => 'Banned IP attempting access',
]);
?>
