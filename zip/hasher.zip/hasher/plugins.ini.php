;<?php die();?>
demo = 2
gdpr = 2
assets = 2
files = 2
hooks = 2