<?php
require_once $abs_us_root . $us_url_root . "usersc/plugins/html_purifier/assets/library/HTMLPurifier.auto.php";