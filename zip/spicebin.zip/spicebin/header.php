<?php
//Please don't load code on the header of every page if you don't need it on the header of every page.
// bold("<br>SpiceBin Header.php Loaded");
